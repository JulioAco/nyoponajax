<?php
// ======================
// 🔒 Restricción de dominio
// ======================
$allowedDomain = "inibox.top";
$referer = $_SERVER['HTTP_REFERER'] ?? '';
$host = $_SERVER['HTTP_HOST'] ?? '';

if (
    strpos($host, $allowedDomain) === false &&
    strpos($referer, $allowedDomain) === false
) {
    header("HTTP/1.1 403 Forbidden");
    exit("⚠️ Acceso no permitido. Solo desde $allowedDomain");
}

// ======================
// 🎬 Obtener parámetros
// ======================
$video_mp4 = $_GET['v0'] ?? null;
$video_hls = $_GET['v1'] ?? null;

if (!$video_mp4 && !$video_hls) {
    exit("❌ No se proporcionó ningún video. Usa ?v0=URL (MP4) o ?v1=URL (HLS)");
}

$video_url = $video_mp4 ?: $video_hls;
$type = $video_mp4 ? "mp4" : "hls";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Reproductor - iniBox</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/playskin.css">
  <style>
    html,body {margin:0;padding:0;background:#000;height:100%;overflow:hidden;}
    #player {position:absolute;width:100%!important;height:100%!important;}
  </style>
</head>
<body>
  <div id="player"></div>

  <script src="https://content.jwplatform.com/libraries/KB5zFt7A.js"></script>
  <script>
    const playerInstance = jwplayer("player").setup({
      controls: true,
      sharing: true,
      displaytitle: true,
      displaydescription: true,
      abouttext: "iniBox",
      aboutlink: "https://inibox.top",
      skin: { name: "netflix" },
      logo: {
        file: "https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/images/logo.webp",
        link: "https://inibox.top"
      },
      playlist: [
        {
          file: "<?= htmlspecialchars($video_url, ENT_QUOTES) ?>",
          type: "<?= $type ?>"
        }
      ]
    });

    // 🔹 Avance y retroceso de 10s
    playerInstance.on("ready", function () {
      const playerContainer = playerInstance.getContainer();
      const buttonContainer = playerContainer.querySelector(".jw-button-container");
      const rewindContainer = playerContainer.querySelector(".jw-display-icon-rewind");
      const forwardContainer = rewindContainer.cloneNode(true);
      const forwardDisplayButton = forwardContainer.querySelector(".jw-icon-rewind");
      forwardDisplayButton.style.transform = "scaleX(-1)";
      forwardDisplayButton.ariaLabel = "Avanzar 10 segundos";
      const nextContainer = playerContainer.querySelector(".jw-display-icon-next");
      nextContainer.parentNode.insertBefore(forwardContainer, nextContainer);

      // ocultar "siguiente"
      playerContainer.querySelector(".jw-display-icon-next").style.display = "none";
      const rewindControlBarButton = buttonContainer.querySelector(".jw-icon-rewind");
      const forwardControlBarButton = rewindControlBarButton.cloneNode(true);
      forwardControlBarButton.style.transform = "scaleX(-1)";
      forwardControlBarButton.ariaLabel = "Avanzar 10 segundos";
      rewindControlBarButton.parentNode.insertBefore(forwardControlBarButton, rewindControlBarButton.nextElementSibling);

      // eventos
      [forwardDisplayButton, forwardControlBarButton].forEach((btn) => {
        btn.onclick = () => {
          playerInstance.seek(playerInstance.getPosition() + 10);
        };
      });
    });
  </script>
</body>
</html>
