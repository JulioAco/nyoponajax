<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';


// Obtener películas de la base de datos
try {
    $pdo = getDBConnection();
    
    // Obtener películas destacadas
    $stmt = $pdo->prepare("
        SELECT * FROM peliculas 
        WHERE group_id = 1 
        ORDER BY fecha_creacion DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $peliculas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener películas por categorías
    $categorias = ['Acción', 'Drama', 'Comedia', 'Ciencia Ficción'];
    $peliculas_por_categoria = [];
    
    foreach ($categorias as $categoria) {
        $stmt = $pdo->prepare("
            SELECT * FROM peliculas 
            WHERE etiquetas LIKE :categoria 
            ORDER BY puntuacion DESC 
            LIMIT 10
        ");
        $stmt->execute([':categoria' => '%' . $categoria . '%']);
        $peliculas_por_categoria[$categoria] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
} catch (PDOException $e) {
    error_log("Error al obtener películas: " . $e->getMessage());
    $peliculas = [];
    $peliculas_por_categoria = [];
}

// Cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Inicio</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />

  <style>
    :root {
      --bg: #000000;
      --bg-secondary: #151515;
      --card-bg: #1c1c1e;
      --text: #ffffff;
      --text-secondary: #ebebf599;
      --green: #30d158;
      --radius: 1.5rem;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    
    html, body {
      height: 100%;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      overflow-x: hidden;
    }
    
    /* Header estilo iOS */
    header {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      background: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 1000;
      border-bottom: 0.5px solid rgba(255, 255, 255, 0.1);
    }
    
    .logo {
      display: flex;
      align-items: center;
    }
    
    .logo img {
      height: 32px;
      user-select: none;
    }
    
    .header-title {
      font-size: 1.5rem;
      font-weight: 700;
      letter-spacing: -0.5px;
    }
    
    .header-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    
    .icon-button {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: var(--text);
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .icon-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    /* Contenido principal */
    main {
      padding: 1.5rem;
      padding-bottom: 5rem;
    }
    
    /* Sección destacada */
    .featured-section {
      margin-bottom: 2.5rem;
    }
    
    .section-title {
      font-size: 1.35rem;
      font-weight: 700;
      margin-bottom: 1.25rem;
      letter-spacing: -0.25px;
      padding-left: 0.5rem;
    }
    
    .featured-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
      gap: 1.25rem;
    }
    
    .movie-card {
      border-radius: var(--radius);
      overflow: hidden;
      transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
      background: var(--card-bg);
      aspect-ratio: 2/3;
    }
    
    .movie-card:hover {
      transform: scale(1.05);
    }
    
    .movie-poster {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    
    /* Categorías */
    .category-section {
      margin-bottom: 2.5rem;
    }
    
    .category-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
      gap: 1.25rem;
    }
    
    /* Barra de navegación inferior estilo iOS */
    .bottom-nav {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 0.75rem 1rem;
      background: rgba(28, 28, 30, 0.9);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-top: 0.5px solid rgba(255, 255, 255, 0.1);
      z-index: 1000;
    }
    
    .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      color: var(--text-secondary);
      font-size: 0.7rem;
      gap: 0.25rem;
      padding: 0.5rem;
      border-radius: var(--radius);
      transition: all 0.2s;
    }
    
    .nav-item.active {
      color: var(--green);
    }
    
    .nav-item:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .nav-icon {
      font-size: 1.5rem;
      font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
    }
    
    .nav-item.active .nav-icon {
      font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24;
    }
    
    /* Modal para trailers */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.9);
      z-index: 2000;
      justify-content: center;
      align-items: center;
      opacity: 0;
      transition: opacity 0.3s;
    }
    
    .modal.show {
      display: flex;
      opacity: 1;
    }
    
    .modal-content {
      position: relative;
      width: 90%;
      max-width: 900px;
    }
    
    .close-modal {
      position: absolute;
      top: -45px;
      right: 0;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 1.25rem;
      transition: background 0.2s;
    }
    
    .close-modal:hover {
      background: rgba(255, 255, 255, 0.3);
    }
    
    .trailer-container {
      position: relative;
      padding-bottom: 56.25%;
      height: 0;
      border-radius: var(--radius);
      overflow: hidden;
    }
    
    .trailer-iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      border: none;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .featured-grid {
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
        gap: 1rem;
      }
      
      .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
        gap: 1rem;
      }
      
      .header-title {
        font-size: 1.25rem;
      }
    }
    
    @media (max-width: 480px) {
      main {
        padding: 1rem;
        padding-bottom: 5rem;
      }
      
      .featured-grid {
        grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
        gap: 0.8rem;
      }
      
      .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 0.8rem;
      }
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">
      <span class="header-title">Titan</span>
    </div>
    
    <div class="header-actions">
      <button class="icon-button" onclick="openSearch()">
        <span class="material-symbols-rounded">search</span>
      </button>
      <button class="icon-button" onclick="location.href='?logout=true'">
        <span class="material-symbols-rounded">logout</span>
      </button>
    </div>
  </header>
  
  <main>
    <!-- Sección destacada -->
    <section class="featured-section">
      <h2 class="section-title">Destacadas</h2>
      <div class="featured-grid">
        <?php foreach ($peliculas as $pelicula): ?>
        <div class="movie-card" onclick="playTrailer('<?php echo htmlspecialchars($pelicula['trailer_id']); ?>')">
          <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" class="movie-poster">
        </div>
        <?php endforeach; ?>
      </div>
    </section>
    
    <!-- Secciones por categoría -->
    <?php foreach ($peliculas_por_categoria as $categoria => $peliculas_categoria): ?>
      <?php if (!empty($peliculas_categoria)): ?>
      <section class="category-section">
        <h2 class="section-title"><?php echo htmlspecialchars($categoria); ?></h2>
        <div class="category-grid">
          <?php foreach ($peliculas_categoria as $pelicula): ?>
          <a href="pelicula.php?id=<?php echo $pelicula['id']; ?>" class="movie-card">
  <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" class="movie-poster">
</a>

          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>
    <?php endforeach; ?>
  </main>
  
  <!-- Barra de navegación inferior -->
  <nav class="bottom-nav">
    <a href="home.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">home</span>
      <span>Inicio</span>
    </a>
    <a href="peliculas.php" class="nav-item active">
      <span class="material-symbols-rounded nav-icon">movie</span>
      <span>Películas</span>
    </a>
    <a href="series.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">live_tv</span>
      <span>Series</span>
    </a>
    <a href="buscar.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">search</span>
      <span>Buscar</span>
    </a>
    <a href="?logout=true" class="nav-item">
      <span class="material-symbols-rounded nav-icon">account_circle</span>
      <span>Cuenta</span>
    </a>
  </nav>
  
  <!-- Modal para trailers -->
  <div id="trailer-modal" class="modal">
    <div class="modal-content">
      <button class="close-modal" onclick="closeModal()">×</button>
      <div class="trailer-container">
        <iframe id="trailer-iframe" class="trailer-iframe" src="" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
  
  <script>
    function playTrailer(trailerId) {
      const modal = document.getElementById('trailer-modal');
      const iframe = document.getElementById('trailer-iframe');
      iframe.src = `https://www.youtube.com/embed/${trailerId}?autoplay=1`;
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    
    function closeModal() {
      const modal = document.getElementById('trailer-modal');
      const iframe = document.getElementById('trailer-iframe');
      iframe.src = '';
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }
    
    // Cerrar modal al hacer clic fuera del contenido
    document.getElementById('trailer-modal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeModal();
      }
    });
    
    function openSearch() {
      alert('Funcionalidad de búsqueda próximamente');
    }
    
    // Confirmar cierre de sesión
    document.querySelector('a[href="?logout=true"]').addEventListener('click', function(e) {
      e.preventDefault();
      if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
        window.location.href = '?logout=true';
      }
    });
  </script>
</body>
</html>