<?php
ob_start(); // Iniciar buffer de salida para evitar problemas con encabezados
session_start();
require_once 'includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo = trim($_POST['codigo'] ?? '');
    if (empty($codigo)) {
        $error = "Debes ingresar un código";
    } else {
        try {
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("SELECT * FROM invitaciones WHERE codigo = ? AND activo = 1");
            $stmt->execute([$codigo]);
            $invitacion = $stmt->fetch();

            if ($invitacion) {
                $_SESSION['token'] = $codigo;
                $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'];
                header("Location: home.php");
                ob_end_flush(); // Liberar buffer y enviar encabezados
                exit;
            } else {
                $error = "Código inválido o inactivo";
            }
        } catch (PDOException $e) {
            error_log("Error al validar código: " . $e->getMessage());
            $error = "Error al procesar. Inténtalo de nuevo.";
        }
    }
}
ob_end_flush(); // Liberar buffer si no se redirige
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Acceso por código</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@300" rel="stylesheet" />

  <style>
    :root{
      --bg:#0b0b0b;
      --text:#e9e9e9;
      --muted:#a0a0a0;
      --green:#29d14d;
      --radius:14px;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      background:var(--bg);
      color:var(--text);
      font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;
      display:grid;
      place-items:center;
    }
    .wrap{
      width:min(520px,92vw);
      padding:32px 24px 24px;
    }
    .logo{
      display:grid;
      place-items:center;
      margin:10vh 0 40px;
    }
    .logo img{
      width:min(300px,30vw);
      max-width:360px;
      user-select:none;
    }
    label{
      display:block;
      font-size:.95rem;
      margin:0 0 8px;
      color:var(--muted);
    }
    .field{
      position:relative;
      display:flex;
      align-items:center;
    }
    input{
      width:100%;
      height:58px;
      background:transparent;
      color:var(--text);
      border:2px solid var(--green);
      border-radius:var(--radius);
      outline:none;
      padding:0 56px 0 18px;
      font-size:1.05rem;
      letter-spacing:.6px;
      transition:border-color .2s;
    }
    input:focus{
      border-color:var(--green);
    }
    .eye{
      position:absolute;
      right:8px;
      height:42px;
      width:42px;
      border:0;
      background:transparent;
      color:var(--text);
      border-radius:12px;
      cursor:pointer;
      display:grid;
      place-items:center;
    }
    .eye:hover{background:#ffffff12}
    .btn{
      margin-top:26px;
      width:100%;
      height:58px;
      border:2px solid var(--green);
      background:transparent;
      color:var(--green);
      border-radius:var(--radius);
      font-weight:600;
      letter-spacing:.28em;
      text-transform:uppercase;
      cursor:pointer;
      transition:transform .06s ease, background .2s;
    }
    .btn:active{transform:translateY(1px)}
    .btn:hover{background:#0f0f0f}
    .helper{
      margin-top:18px;
      text-align:center;
      color:var(--muted);
      font-size:.95rem;
    }
    .helper a{
      color:var(--text);
      text-decoration:none;
      font-weight:600;
      border-bottom:1px solid transparent;
      transition:color .2s, border-color .2s;
    }
    .helper a:hover{
      color:var(--green);
      border-color:var(--green);
    }
    .error{
      color:#ff4d4d;
      text-align:center;
      margin-top:18px;
      font-size:.95rem;
    }
  </style>
</head>
<body>
  <main class="wrap">
    <div class="logo">
      <img src="https://cdn.stickers.gg/stickers/4196-doog-street.png" alt="Logo" />
    </div>

    <form id="form" method="POST" autocomplete="off" novalidate>
      <label for="codigo">Código de invitación</label>
      <div class="field">
        <input id="codigo" name="codigo" type="password" placeholder="Ingresa tu código" required />
        <button class="eye" type="button" aria-label="Mostrar u ocultar código">
          <span class="material-symbols-rounded">visibility</span>
        </button>
      </div>

      <button class="btn" type="submit">ACCEDER</button>

      <p class="helper">
        ¿No tienes código de invitación?
        <a href="https://forms.gle/qi5qvAH4xzFjynyb7" target="_blank" id="obtener">OBTENER CÓDIGO AQUÍ</a>
      </p>

      <?php if (isset($error)): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>
    </form>
  </main>

  <script>
    const input = document.getElementById('codigo');
    const eyeBtn = document.querySelector('.eye');
    const eyeIcon = eyeBtn.querySelector('.material-symbols-rounded');

    eyeBtn.addEventListener('click', () => {
      const isPwd = input.type === 'password';
      input.type = isPwd ? 'text' : 'password';
      eyeIcon.textContent = isPwd ? 'visibility_off' : 'visibility';
    });
  </script>
</body>
</html>