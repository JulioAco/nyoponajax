<?php
session_start();
require_once 'includes/config.php';

// Verificar si el usuario tiene una sesión válida
if (!isset($_SESSION['token']) || $_SESSION['user_ip'] !== $_SERVER['REMOTE_ADDR']) {
    header("Location: index.php");
    exit;
}

// Obtener datos de la base de datos
try {
    $pdo = getDBConnection();
    
    // Obtener películas destacadas
    $stmt = $pdo->prepare("
        SELECT * FROM peliculas 
        WHERE group_id = 1 
        ORDER BY fecha_creacion DESC 
        LIMIT 12
    ");
    $stmt->execute();
    $peliculas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener series destacadas
    $stmt = $pdo->prepare("
        SELECT * FROM series 
        WHERE group_id = 1 
        ORDER BY fecha_creacion DESC 
        LIMIT 12
    ");
    $stmt->execute();
    $series = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener episodios recientes (últimos 10 episodios agregados)
    $stmt = $pdo->prepare("
        SELECT e.*, s.nombre as serie_nombre, s.portada_url as serie_portada
        FROM episodios e
        JOIN series s ON e.serie_id = s.id
        WHERE e.group_id = 1 
        ORDER BY e.fecha_creacion DESC 
        LIMIT 10
    ");
    $stmt->execute();
    $episodios_recientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener estrenos (películas y series agregadas en los últimos 7 días)
    $stmt = $pdo->prepare("
        (SELECT id, titulo as nombre, portada_url, 'pelicula' as tipo, fecha_creacion 
         FROM peliculas 
         WHERE group_id = 1 AND fecha_creacion >= DATE_SUB(NOW(), INTERVAL 7 DAY)
         ORDER BY fecha_creacion DESC 
         LIMIT 8)
        UNION
        (SELECT id, nombre, portada_url, 'serie' as tipo, fecha_creacion 
         FROM series 
         WHERE group_id = 1 AND fecha_creacion >= DATE_SUB(NOW(), INTERVAL 7 DAY)
         ORDER BY fecha_creacion DESC 
         LIMIT 8)
        ORDER BY fecha_creacion DESC 
        LIMIT 16
    ");
    $stmt->execute();
    $estrenos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener películas por categorías
    $categorias_peliculas = ['Acción', 'Drama', 'Comedia', 'Ciencia Ficción'];
    $peliculas_por_categoria = [];
    
    foreach ($categorias_peliculas as $categoria) {
        $stmt = $pdo->prepare("
            SELECT * FROM peliculas 
            WHERE etiquetas LIKE :categoria 
            ORDER BY puntuacion DESC 
            LIMIT 10
        ");
        $stmt->execute([':categoria' => '%' . $categoria . '%']);
        $peliculas_por_categoria[$categoria] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Obtener series por categorías
    $categorias_series = ['Drama', 'Comedia', 'Acción', 'Ciencia Ficción'];
    $series_por_categoria = [];
    
    foreach ($categorias_series as $categoria) {
        $stmt = $pdo->prepare("
            SELECT * FROM series 
            WHERE etiquetas LIKE :categoria 
            ORDER BY puntuacion DESC 
            LIMIT 10
        ");
        $stmt->execute([':categoria' => '%' . $categoria . '%']);
        $series_por_categoria[$categoria] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
} catch (PDOException $e) {
    error_log("Error al obtener datos: " . $e->getMessage());
    $peliculas = $series = $episodios_recientes = $estrenos = [];
    $peliculas_por_categoria = $series_por_categoria = [];
}

// Cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Inicio</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/home.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/ajaxlmain.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/materialize.css">

</head>
<body>
  
  <main>
    <!-- Sección de Estrenos -->
    <?php if (!empty($estrenos)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Estrenos Recientes</h2>
        <a href="#" class="view-all">Ver todos</a>
      </div>
      <div class="grid featured-grid">
        <?php foreach ($estrenos as $estreno): ?>
        <a href="<?php echo $estreno['tipo'] === 'pelicula' ? 'pelicula.php?id=' : 'serie.php?id='; ?><?php echo $estreno['id']; ?>" class="card estreno-card loading">
          <img src="<?php echo htmlspecialchars($estreno['portada_url']); ?>" alt="<?php echo htmlspecialchars($estreno['nombre']); ?>" class="card-image">
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Sección de Episodios Recientes -->
    <?php if (!empty($episodios_recientes)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Episodios Recientes</h2>
        <a href="#" class="view-all">Ver todos</a>
      </div>
      <div class="grid episodes-grid">
        <?php foreach ($episodios_recientes as $episodio): ?>
        <a href="serie.php?id=<?php echo $episodio['serie_id']; ?>" class="card episode-card loading">
          <img src="<?php echo !empty($episodio['imagen_episodio']) ? htmlspecialchars($episodio['imagen_episodio']) : htmlspecialchars($episodio['serie_portada']); ?>" alt="<?php echo htmlspecialchars($episodio['serie_nombre']); ?>" class="card-image">
          <div class="episode-overlay">
            <div class="episode-title"><?php echo htmlspecialchars($episodio['serie_nombre']); ?></div>
            <div class="episode-info">
              <span>T<?php echo $episodio['temporada']; ?> E<?php echo $episodio['episodio']; ?></span>
              <span>•</span>
              <span><?php echo htmlspecialchars($episodio['titulo']); ?></span>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Sección de Películas Destacadas -->
    <?php if (!empty($peliculas)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Películas Destacadas</h2>
        <a href="peliculas.php" class="view-all">Ver todas</a>
      </div>
      <div class="grid featured-grid">
        <?php foreach ($peliculas as $pelicula): ?>
        <a href="pelicula.php?id=<?php echo $pelicula['id']; ?>" class="card movie-card loading">
          <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" class="card-image">
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Sección de Series Destacadas -->
    <?php if (!empty($series)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Series Destacadas</h2>
        <a href="series.php" class="view-all">Ver todas</a>
      </div>
      <div class="grid featured-grid">
        <?php foreach ($series as $serie): ?>
        <a href="serie.php?id=<?php echo $serie['id']; ?>" class="card serie-card loading">
          <img src="<?php echo htmlspecialchars($serie['portada_url']); ?>" alt="<?php echo htmlspecialchars($serie['nombre']); ?>" class="card-image">
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Secciones de Películas por Categoría -->
    <?php foreach ($peliculas_por_categoria as $categoria => $peliculas_categoria): ?>
      <?php if (!empty($peliculas_categoria)): ?>
      <section class="section">
        <h2 class="section-title">Películas de <?php echo htmlspecialchars($categoria); ?></h2>
        <div class="grid category-grid">
          <?php foreach ($peliculas_categoria as $pelicula): ?>
          <a href="pelicula.php?id=<?php echo $pelicula['id']; ?>" class="card movie-card loading">
            <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" class="card-image">
          </a>
          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>
    <?php endforeach; ?>

    <!-- Secciones de Series por Categoría -->
    <?php foreach ($series_por_categoria as $categoria => $series_categoria): ?>
      <?php if (!empty($series_categoria)): ?>
      <section class="section">
        <h2 class="section-title">Series de <?php echo htmlspecialchars($categoria); ?></h2>
        <div class="grid category-grid">
          <?php foreach ($series_categoria as $serie): ?>
          <a href="serie.php?id=<?php echo $serie['id']; ?>" class="card serie-card loading">
            <img src="<?php echo htmlspecialchars($serie['portada_url']); ?>" alt="<?php echo htmlspecialchars($serie['nombre']); ?>" class="card-image">
          </a>
          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>
    <?php endforeach; ?>
  </main>

  
  <!-- Modal para trailers -->
  <div id="trailer-modal" class="modal">
    <div class="modal-content">
      <button class="close-modal" onclick="closeModal()">×</button>
      <div class="trailer-container">
        <iframe id="trailer-iframe" class="trailer-iframe" src="" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
  
  <script>
    function playTrailer(trailerId) {
      const modal = document.getElementById('trailer-modal');
      const iframe = document.getElementById('trailer-iframe');
      iframe.src = `https://www.youtube.com/embed/${trailerId}?autoplay=1`;
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    
    function closeModal() {
      const modal = document.getElementById('trailer-modal');
      const iframe = document.getElementById('trailer-iframe');
      iframe.src = '';
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }
    
    // Cerrar modal al hacer clic fuera del contenido
    document.getElementById('trailer-modal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeModal();
      }
    });
    
    function openSearch() {
      alert('Funcionalidad de búsqueda próximamente');
    }
    
    // Confirmar cierre de sesión
    document.querySelector('a[href="?logout=true"]').addEventListener('click', function(e) {
      e.preventDefault();
      if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
        window.location.href = '?logout=true';
      }
    });
  </script>
  <script>
// Quitar animación de carga cuando la imagen termine de cargar
document.querySelectorAll('.card img').forEach(img => {
  const card = img.closest('.card');

  // Si ya está cargada (cache del navegador)
  if (img.complete) {
    card.classList.remove('loading');
  } else {
    img.addEventListener('load', () => {
      card.classList.remove('loading');
    });

    img.addEventListener('error', () => {
      card.classList.remove('loading');
    });
  }
});

  </script>
  <script>
// Loader avanzado con JS
document.addEventListener("DOMContentLoaded", function () {
  // Crear overlay
  const overlay = document.createElement("div");
  overlay.id = "loader-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "0";
  overlay.style.left = "0";
  overlay.style.width = "100%";
  overlay.style.height = "100%";
  overlay.style.background = "#000"; // fondo oscuro
  overlay.style.display = "flex";
  overlay.style.alignItems = "center";
  overlay.style.justifyContent = "center";
  overlay.style.zIndex = "9999";

  // Insertar loader
  overlay.innerHTML = `<span class="loader"></span>`;
  document.body.appendChild(overlay);

  // Al cargar todo el contenido -> quitar loader
  window.addEventListener("load", () => {
    setTimeout(() => {
      overlay.style.opacity = "0";
      overlay.style.transition = "opacity 0.6s ease";
      setTimeout(() => overlay.remove(), 600);
    }, 4000); // pequeño delay para elegancia
  });
});
</script>

</body>
</html>