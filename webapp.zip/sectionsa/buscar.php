<?php
session_start();
require_once 'includes/config.php';

// Verificar si el usuario tiene una sesión válida
if (!isset($_SESSION['token']) || $_SESSION['user_ip'] !== $_SERVER['REMOTE_ADDR']) {
    header("Location: index.php");
    exit;
}

// Procesar búsqueda si se envió por AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['query'])) {
    header('Content-Type: application/json');
    
    $query = isset($_POST['query']) ? trim($_POST['query']) : '';
    $results = [];
    
    // Si la consulta está vacía, devolver resultados vacíos
    if (empty($query)) {
        echo json_encode(['results' => $results, 'message' => 'Consulta vacía']);
        exit;
    }
    
    try {
        $pdo = getDBConnection();
        
        // Preparar el término de búsqueda
        $searchTerm = '%' . $query . '%';
        
        // Buscar en películas - CORREGIDO: usar el mismo nombre de parámetro
        $stmt = $pdo->prepare("
            SELECT id, titulo AS nombre, portada_url, anio AS año, 'pelicula' AS tipo
            FROM peliculas 
            WHERE (titulo LIKE :query OR titulo_original LIKE :query2)
        ");
        $stmt->execute([
            ':query' => $searchTerm,
            ':query2' => $searchTerm
        ]);
        $peliculas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Buscar en series - CORREGIDO: usar el mismo nombre de parámetro
        $stmt = $pdo->prepare("
            SELECT id, nombre, portada_url, anio_inicio AS año, 'serie' AS tipo
            FROM series 
            WHERE (nombre LIKE :query OR nombre_original LIKE :query2)
        ");
        $stmt->execute([
            ':query' => $searchTerm,
            ':query2' => $searchTerm
        ]);
        $series = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $results = array_merge($peliculas, $series);
        
        // Ordenar resultados alfabéticamente
        usort($results, function($a, $b) {
            return strcmp($a['nombre'], $b['nombre']);
        });
        
        echo json_encode(['results' => $results, 'success' => true]);
        
    } catch (PDOException $e) {
        error_log("Error en búsqueda: " . $e->getMessage());
        echo json_encode(['error' => 'Error en la base de datos: ' . $e->getMessage(), 'success' => false]);
    }
    exit;
}

// Cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Buscar</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />

  <style>
    :root {
      --bg: #000000;
      --bg-secondary: #151515;
      --card-bg: #1c1c1e;
      --text: #ffffff;
      --text-secondary: #ebebf599;
      --green: #30d158;
      --radius: 1.5rem;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    
    html, body {
      height: 100%;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      overflow-x: hidden;
    }
    
    /* Header estilo iOS */
    header {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      background: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 1000;
      border-bottom: 0.5px solid rgba(255, 255, 255, 0.1);
    }
    
    .back-button {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: var(--text);
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .back-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    .header-title {
      font-size: 1.1rem;
      font-weight: 600;
      letter-spacing: -0.5px;
      text-align: center;
      flex: 1;
      padding: 0 1rem;
    }
    
    /* Barra de búsqueda */
    .search-container {
      padding: 1.5rem;
    }
    
    .search-box {
      position: relative;
      margin-bottom: 1.5rem;
    }
    
    .search-input {
      width: 100%;
      padding: 1rem 1rem 1rem 3rem;
      background: var(--card-bg);
      border: 2px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--radius);
      color: var(--text);
      font-size: 1rem;
      outline: none;
      transition: border-color 0.2s;
    }
    
    .search-input:focus {
      border-color: var(--green);
    }
    
    .search-icon {
      position: absolute;
      left: 1rem;
      top: 50%;
      transform: translateY(-50%);
      color: var(--text-secondary);
    }
    
    .clear-search {
      position: absolute;
      right: 1rem;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      color: var(--text-secondary);
      cursor: pointer;
      display: none;
    }
    
    .search-input:not(:placeholder-shown) + .clear-search {
      display: block;
    }
    
    /* Resultados de búsqueda */
    .results-container {
      min-height: 60vh;
    }
    
    .no-results {
      text-align: center;
      color: var(--text-secondary);
      padding: 2rem;
    }
    
    .no-results-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
      opacity: 0.5;
    }
    
    .results-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 1.25rem;
    }
    
    .result-card {
      border-radius: var(--radius);
      overflow: hidden;
      transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
      background: var(--card-bg);
      aspect-ratio: 2/3;
    }
    
    .result-card:hover {
      transform: scale(1.05);
    }
    
    .result-poster {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    
    .result-info {
      padding: 0.5rem;
    }
    
    .result-title {
      font-weight: 600;
      margin-bottom: 0.25rem;
      font-size: 0.9rem;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .result-details {
      display: flex;
      justify-content: space-between;
      color: var(--text-secondary);
      font-size: 0.8rem;
    }
    
    .result-type {
      text-transform: capitalize;
    }
    
    .result-year {
      color: var(--green);
    }
    
    .loading {
      text-align: center;
      padding: 2rem;
      color: var(--text-secondary);
    }
    
    .loading-spinner {
      display: inline-block;
      width: 20px;
      height: 20px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-radius: 50%;
      border-top-color: var(--green);
      animation: spin 1s ease-in-out infinite;
      margin-right: 0.5rem;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    
    /* Barra de navegación inferior estilo iOS */
    .bottom-nav {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 0.75rem 1rem;
      background: rgba(28, 28, 30, 0.9);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-top: 0.5px solid rgba(255, 255, 255, 0.1);
      z-index: 1000;
    }
    
    .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      color: var(--text-secondary);
      font-size: 0.7rem;
      gap: 0.25rem;
      padding: 0.5rem;
      border-radius: var(--radius);
      transition: all 0.2s;
    }
    
    .nav-item.active {
      color: var(--green);
    }
    
    .nav-item:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .nav-icon {
      font-size: 1.5rem;
      font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
    }
    
    .nav-item.active .nav-icon {
      font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .results-grid {
        grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
        gap: 1rem;
      }
    }
    
    @media (max-width: 480px) {
      .search-container {
        padding: 1rem;
      }
      
      .results-grid {
        grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
        gap: 0.8rem;
      }
    }
  </style>
</head>
<body>
  <header>
    <button class="back-button" onclick="history.back()">
      <span class="material-symbols-rounded">arrow_back</span>
    </button>
    <div class="header-title">Buscar</div>
    <div style="width: 40px;"></div>
  </header>
  
  <div class="search-container">
    <div class="search-box">
      <input type="text" id="search-input" class="search-input" placeholder="Buscar películas y series..." autocomplete="off">
      <span class="material-symbols-rounded search-icon">search</span>
      <button class="clear-search" onclick="clearSearch()">
        <span class="material-symbols-rounded">close</span>
      </button>
    </div>
    
    <div class="results-container" id="results-container">
      <div class="no-results" id="initial-state">
        <div class="no-results-icon">
          <span class="material-symbols-rounded">search</span>
        </div>
        <p>Busca películas y series</p>
      </div>
    </div>
  </div>
  
  <!-- Barra de navegación inferior -->
  <nav class="bottom-nav">
    <a href="homev2.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">home</span>
      <span>Inicio</span>
    </a>
    <a href="peliculas.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">movie</span>
      <span>Películas</span>
    </a>
    <a href="series.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">live_tv</span>
      <span>Series</span>
    </a>
    <a href="buscar.php" class="nav-item active">
      <span class="material-symbols-rounded nav-icon">search</span>
      <span>Buscar</span>
    </a>
    <a href="?logout=true" class="nav-item">
      <span class="material-symbols-rounded nav-icon">account_circle</span>
      <span>Cuenta</span>
    </a>
  </nav>
  
  <script>
    let searchTimeout;
    const searchInput = document.getElementById('search-input');
    const resultsContainer = document.getElementById('results-container');
    
    // Función para buscar
    function performSearch(query) {
      if (query.length < 2) {
        showInitialState();
        return;
      }
      
      showLoading();
      
      // Cancelar búsqueda anterior si existe
      if (window.currentSearchRequest) {
        window.currentSearchRequest.abort();
      }
      
      // Crear nueva solicitud
      window.currentSearchRequest = new AbortController();
      const signal = window.currentSearchRequest.signal;
      
      const formData = new FormData();
      formData.append('query', query);
      
      fetch('buscar.php', {
        method: 'POST',
        body: formData,
        signal: signal
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Error en la respuesta del servidor: ' + response.status);
        }
        return response.json();
      })
      .then(data => {
        // Verificar si hay error en la respuesta
        if (data && data.error) {
          console.error('Error del servidor:', data.error);
          showError('Error del servidor: ' + data.error);
          return;
        }
        
        // Verificar si la respuesta tiene el formato esperado
        if (data && data.results !== undefined) {
          displayResults(data.results, query);
        } else if (Array.isArray(data)) {
          // Formato antiguo (solo array)
          displayResults(data, query);
        } else {
          console.error('Formato de respuesta inesperado:', data);
          showError('Formato de respuesta inesperado del servidor');
        }
      })
      .catch(error => {
        if (error.name !== 'AbortError') {
          console.error('Error en la búsqueda:', error);
          showError('Error al conectar con el servidor: ' + error.message);
        }
      });
    }
    
    // Mostrar estado inicial
    function showInitialState() {
      resultsContainer.innerHTML = `
        <div class="no-results" id="initial-state">
          <div class="no-results-icon">
            <span class="material-symbols-rounded">search</span>
          </div>
          <p>Busca películas y series</p>
        </div>
      `;
    }
    
    // Mostrar carga
    function showLoading() {
      resultsContainer.innerHTML = `
        <div class="loading">
          <span class="loading-spinner"></span>
          Buscando...
        </div>
      `;
    }
    
    // Mostrar error
    function showError(message = 'Error al buscar. Intenta nuevamente.') {
      resultsContainer.innerHTML = `
        <div class="no-results">
          <div class="no-results-icon">
            <span class="material-symbols-rounded">error</span>
          </div>
          <p>${message}</p>
          <p style="font-size: 0.8rem; margin-top: 0.5rem;">Abre la consola (F12) para más detalles</p>
        </div>
      `;
    }
    
    // Mostrar resultados
    function displayResults(results, query) {
      if (!results || results.length === 0) {
        resultsContainer.innerHTML = `
          <div class="no-results">
            <div class="no-results-icon">
              <span class="material-symbols-rounded">search_off</span>
            </div>
            <p>No se encontraron resultados para "<strong>${query}</strong>"</p>
            <p style="font-size: 0.8rem; margin-top: 0.5rem;">Intenta con otras palabras</p>
          </div>
        `;
        return;
      }
      
      let html = '<div class="results-grid">';
      
      results.forEach(item => {
        const year = item.año || item.anio || '';
        const tipo = item.tipo === 'pelicula' || item.tipo === 'movie' ? 'Película' : 'Serie';
        const link = (item.tipo === 'pelicula' || item.tipo === 'movie') ? `pelicula.php?id=${item.id}` : `serie.php?id=${item.id}`;
        const nombre = item.nombre || item.titulo || 'Sin título';
        const fallbackImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWMxYzFlIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iI2ViZWJfNTk5IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zNWVtIj5TaW4gaW1hZ2VuPC90ZXh0Pjwvc3ZnPg==';
        
        html += `
          <a href="${link}" class="result-card">
            <img src="${item.portada_url || fallbackImage}" alt="${nombre}" class="result-poster" onerror="this.src='${fallbackImage}'">
            <div class="result-info">
              <div class="result-title">${nombre}</div>
              <div class="result-details">
                <span class="result-type">${tipo}</span>
                ${year ? `<span class="result-year">${year}</span>` : ''}
              </div>
            </div>
          </a>
        `;
      });
      
      html += '</div>';
      resultsContainer.innerHTML = html;
      
      // Debug: mostrar resultados en consola
      console.log('Resultados encontrados:', results.length);
      console.log(results);
    }
    
    // Limpiar búsqueda
    function clearSearch() {
      searchInput.value = '';
      searchInput.focus();
      showInitialState();
      
      // Cancelar búsqueda en curso
      if (window.currentSearchRequest) {
        window.currentSearchRequest.abort();
      }
    }
    
    // Event listeners
    searchInput.addEventListener('input', function() {
      const query = this.value.trim();
      
      // Clear previous timeout
      clearTimeout(searchTimeout);
      
      // Set new timeout
      searchTimeout = setTimeout(() => {
        performSearch(query);
      }, 300); // 300ms debounce
    });
    
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        clearTimeout(searchTimeout);
        performSearch(this.value.trim());
      }
    });
    
    // Focus en el input al cargar la página
    window.addEventListener('load', function() {
      searchInput.focus();
      console.log('Sistema de búsqueda cargado correctamente');
      console.log('Para debugging, abre las herramientas de desarrollador (F12)');
    });
    
    // Confirmar cierre de sesión
    document.querySelector('a[href="?logout=true"]').addEventListener('click', function(e) {
      e.preventDefault();
      if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
        window.location.href = '?logout=true';
      }
    });
  </script>
</body>
</html>