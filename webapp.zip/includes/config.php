<?php
// Configuración de la base de datos
define('DB_HOST', '192.168.1.151:3306');
define('DB_USER', 'gabyy');
define('DB_PASS', '0405@inibox@php');
define('DB_NAME', 'inibox');

// API Key de TMDB
define('TMDB_API_KEY', 'cba183b5a444e65269e542e5c7c15063'); //REEMPLAZA POR TU API
define('TMDB_BASE_URL', 'https://api.themoviedb.org/3/');

// Configuración del dominio
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://";
define('BASE_URL', $protocol . $_SERVER['HTTP_HOST'] . '/');

// Telegram
define('TELEGRAM_BOT_TOKEN', '7084945120:AAHMNlvV-QMDZ8gsopwh9eb93hSMVwZDC4g'); // REEMPLAZA POR TU TOKEN DE BOT
define('TELEGRAM_CHAT_ID', '-4609839196'); // REEMPLAZA POR TU ID DE CANAL O GRUPO

// Conexión PDO
function getDBConnection() {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        error_log("Error de conexión: " . $e->getMessage());
        die("Error al conectar con la base de datos. Por favor, inténtelo más tarde.");
    }
}

// Crear conexión global (opcional)
$pdo = getDBConnection();
?>