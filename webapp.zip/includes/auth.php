<?php
ob_start();
require_once 'config.php';

// Verificar si existe un token en la cookie
if (!isset($_COOKIE['auth_token'])) {
    header("Location: ./index.php");
    ob_end_flush();
    exit;
}

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM invitaciones WHERE token = ? AND activo = 1");
    $stmt->execute([$_COOKIE['auth_token']]);
    $invitacion = $stmt->fetch();
    
    if (!$invitacion) {
        // Token inválido, eliminar la cookie
        setcookie('auth_token', '', time() - 3600, '/');
        header("Location: ./index.php");
        ob_end_flush();
        exit;
    }
} catch (PDOException $e) {
    // Manejo de errores silencioso
    header("Location: ./index.php");
    ob_end_flush();
    exit;
}
ob_end_flush();
?>