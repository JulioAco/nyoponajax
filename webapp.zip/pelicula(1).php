<?php
session_start();
require_once 'includes/config.php';

// Verificar si el usuario tiene una sesión válida
if (!isset($_SESSION['token']) || $_SESSION['user_ip'] !== $_SERVER['REMOTE_ADDR']) {
    header("Location: index.php");
    exit;
}

// Obtener ID de la película desde la URL
$movie_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($movie_id <= 0) {
    header("Location: home.php");
    exit;
}

// Obtener información de la película
try {
    $pdo = getDBConnection();
    
    // Obtener datos de la película
    $stmt = $pdo->prepare("SELECT * FROM peliculas WHERE id = ?");
    $stmt->execute([$movie_id]);
    $pelicula = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pelicula) {
        header("Location: home.php");
        exit;
    }
    
    // Obtener servidores para esta película
    $stmt = $pdo->prepare("SELECT * FROM movie_servers WHERE movie_id = ? ORDER BY servidor, idioma");
    $stmt->execute([$movie_id]);
    $servidores = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Agrupar servidores por tipo e idioma
    $servidores_agrupados = [];
    foreach ($servidores as $servidor) {
        $servidores_agrupados[$servidor['servidor']][$servidor['idioma']][] = $servidor;
    }
    
} catch (PDOException $e) {
    error_log("Error al obtener datos de la película: " . $e->getMessage());
    header("Location: home.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • <?php echo htmlspecialchars($pelicula['titulo']); ?></title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />

  <style>
    :root {
      --bg: #000000;
      --bg-secondary: #151515;
      --card-bg: #1c1c1e;
      --text: #ffffff;
      --text-secondary: #ebebf599;
      --green: #30d158;
      --radius: 1.5rem;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    
    html, body {
      height: 100%;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      overflow-x: hidden;
    }
    
    /* Header estilo iOS */
    header {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      background: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 1000;
      border-bottom: 0.5px solid rgba(255, 255, 255, 0.1);
    }
    
    .back-button {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: var(--text);
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .back-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    .header-title {
      font-size: 1.1rem;
      font-weight: 600;
      letter-spacing: -0.5px;
      text-align: center;
      flex: 1;
      padding: 0 1rem;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    /* Hero section */
    .hero-section {
      position: relative;
      height: 70vh;
      overflow: hidden;
    }
    
    .hero-backdrop {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: linear-gradient(to top, var(--bg) 0%, transparent 50%), 
                        linear-gradient(to bottom, var(--bg) 0%, transparent 20%),
                        url('<?php echo htmlspecialchars($pelicula['backdrop_url']); ?>');
      background-size: cover;
      background-position: center;
      filter: brightness(0.7);
    }
    
    .hero-content {
      position: relative;
      z-index: 2;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      padding: 2rem;
    }
    
    .movie-poster {
      width: 150px;
      height: 225px;
      border-radius: 1rem;
      object-fit: cover;
      margin-bottom: 1.5rem;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }
    
    .movie-title {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
      letter-spacing: -0.5px;
    }
    
    .movie-info {
      display: flex;
      gap: 1rem;
      margin-bottom: 1rem;
      color: var(--text-secondary);
      font-size: 0.9rem;
    }
    
    .action-buttons {
      display: flex;
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .play-button {
      background: var(--green);
      color: black;
      border: none;
      padding: 1rem 2rem;
      border-radius: var(--radius);
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      cursor: pointer;
      transition: transform 0.2s;
    }
    
    .play-button:active {
      transform: scale(0.95);
    }
    
    .info-button {
      background: rgba(255, 255, 255, 0.2);
      color: var(--text);
      border: none;
      padding: 1rem;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }
    
    /* Content section */
    .content-section {
      padding: 2rem 1.5rem;
    }
    
    .section-title {
      font-size: 1.35rem;
      font-weight: 700;
      margin-bottom: 1.25rem;
      letter-spacing: -0.25px;
    }
    
    .synopsis {
      margin-bottom: 2rem;
      line-height: 1.6;
      color: var(--text-secondary);
    }
    
    /* Servers section */
    .servers-container {
      margin-bottom: 2rem;
    }
    
    .server-group {
      margin-bottom: 1.5rem;
    }
    
    .server-name {
      font-size: 1.1rem;
      font-weight: 600;
      margin-bottom: 1rem;
      padding-left: 0.5rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    
    .language-tabs {
      display: flex;
      gap: 0.5rem;
      margin-bottom: 1rem;
      overflow-x: auto;
      padding-bottom: 0.5rem;
    }
    
    .language-tab {
      padding: 0.5rem 1rem;
      background: var(--card-bg);
      border-radius: var(--radius);
      font-size: 0.9rem;
      white-space: nowrap;
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .language-tab.active {
      background: var(--green);
      color: black;
      font-weight: 500;
    }
    
    .server-links {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
      gap: 0.8rem;
    }
    
    .server-link {
      background: var(--card-bg);
      border: none;
      color: var(--text);
      padding: 0.8rem;
      border-radius: var(--radius);
      text-align: center;
      cursor: pointer;
      transition: transform 0.2s, background 0.2s;
      font-size: 0.9rem;
    }
    
    .server-link:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-2px);
    }
    
    .server-link:active {
      transform: translateY(0);
    }
    
    /* Video player modal */
    .video-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: var(--bg);
      z-index: 2000;
      flex-direction: column;
    }
    
    .video-modal.show {
      display: flex;
    }
    
    .video-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background: rgba(0, 0, 0, 0.8);
      border-bottom: 0.5px solid rgba(255, 255, 255, 0.1);
    }
    
    .video-title {
      font-size: 1rem;
      font-weight: 600;
    }
    
    .close-video {
      background: none;
      border: none;
      color: var(--text);
      font-size: 1.5rem;
      cursor: pointer;
    }
    
    .video-container {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 1rem;
    }
    
    .video-player {
      width: 100%;
      max-width: 900px;
      height: 100%;
      max-height: 80vh;
      border: none;
      border-radius: var(--radius);
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .movie-title {
        font-size: 1.7rem;
      }
      
      .hero-content {
        padding: 1.5rem;
      }
      
      .movie-poster {
        width: 120px;
        height: 180px;
      }
      
      .server-links {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
      }
    }
    
    @media (max-width: 480px) {
      .movie-title {
        font-size: 1.5rem;
      }
      
      .hero-section {
        height: 60vh;
      }
      
      .content-section {
        padding: 1.5rem 1rem;
      }
      
      .action-buttons {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body>
  <header>
    <button class="back-button" onclick="history.back()">
      <span class="material-symbols-rounded">arrow_back</span>
    </button>
    <div class="header-title"><?php echo htmlspecialchars($pelicula['titulo']); ?></div>
    <div style="width: 40px;"></div> <!-- Espacio para equilibrar -->
  </header>
  
  <div class="hero-section">
    <div class="hero-backdrop"></div>
    <div class="hero-content">
      <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" class="movie-poster">
      <h1 class="movie-title"><?php echo htmlspecialchars($pelicula['titulo']); ?></h1>
      <div class="movie-info">
        <span><?php echo htmlspecialchars($pelicula['anio']); ?></span>
        <span>•</span>
        <span><?php echo htmlspecialchars($pelicula['duracion']); ?></span>
        <span>•</span>
        <span><?php echo htmlspecialchars($pelicula['etiquetas']); ?></span>
      </div>
      <div class="action-buttons">
        <button class="play-button" onclick="playTrailer()">
          <span class="material-symbols-rounded">play_arrow</span>
          Ver Trailer
        </button>
      </div>
    </div>
  </div>
  
  <div class="content-section">
    <div class="synopsis">
      <h2 class="section-title">Sinopsis</h2>
      <p><?php echo htmlspecialchars($pelicula['sinopsis']); ?></p>
    </div>
    
    <div class="servers-container">
      <h2 class="section-title">Servidores Disponibles</h2>
      
      <?php if (!empty($servidores_agrupados)): ?>
        <?php foreach ($servidores_agrupados as $servidor_nombre => $idiomas): ?>
          <div class="server-group">
            <h3 class="server-name">
              <span class="material-symbols-rounded">dns</span>
              <?php echo htmlspecialchars($servidor_nombre); ?>
            </h3>
            
            <?php if (count($idiomas) > 1): ?>
              <div class="language-tabs" id="tabs-<?php echo htmlspecialchars($servidor_nombre); ?>">
                <?php $first = true; ?>
                <?php foreach ($idiomas as $idioma => $links): ?>
                  <div class="language-tab <?php echo $first ? 'active' : ''; ?>" 
                       data-target="<?php echo htmlspecialchars($servidor_nombre . '-' . $idioma); ?>">
                    <?php echo htmlspecialchars($idioma); ?>
                  </div>
                  <?php $first = false; ?>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
            
            <?php foreach ($idiomas as $idioma => $links): ?>
              <div class="server-links <?php echo count($idiomas) > 1 ? 'language-content' : ''; ?>" 
                   id="<?php echo htmlspecialchars($servidor_nombre . '-' . $idioma); ?>"
                   style="<?php echo count($idiomas) > 1 ? 'display: none;' : ''; ?>">
                <?php foreach ($links as $link): ?>
                  <button class="server-link" onclick="playVideo('<?php echo htmlspecialchars($link['url_video']); ?>', '<?php echo htmlspecialchars($link['link_type']); ?>')">
                    <span class="material-symbols-rounded" style="font-size: 1.2rem; margin-bottom: 0.2rem;">play_circle</span>
                    <br>
                    <?php echo htmlspecialchars($link['idioma']); ?>
                  </button>
                <?php endforeach; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p>No hay servidores disponibles para esta película.</p>
      <?php endif; ?>
    </div>
  </div>
  
  <!-- Modal para video -->
  <div id="video-modal" class="video-modal">
    <div class="video-header">
      <div class="video-title">Reproduciendo: <?php echo htmlspecialchars($pelicula['titulo']); ?></div>
      <button class="close-video" onclick="closeVideo()">
        <span class="material-symbols-rounded">close</span>
      </button>
    </div>
    <div class="video-container">
      <iframe id="video-player" class="video-player" src="" allowfullscreen></iframe>
    </div>
  </div>
  
  <script>
    // Funcionalidad de pestañas de idioma
    document.querySelectorAll('.language-tabs').forEach(tabsContainer => {
      const tabs = tabsContainer.querySelectorAll('.language-tab');
      tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          const targetId = tab.getAttribute('data-target');
          
          // Ocultar todos los contenidos del mismo grupo
          tab.closest('.server-group').querySelectorAll('.language-content').forEach(content => {
            content.style.display = 'none';
          });
          
          // Mostrar el contenido seleccionado
          document.getElementById(targetId).style.display = 'grid';
          
          // Actualizar pestañas activas
          tabs.forEach(t => t.classList.remove('active'));
          tab.classList.add('active');
        });
      });
    });
    
    // Reproducir trailer
    function playTrailer() {
      const modal = document.getElementById('video-modal');
      const player = document.getElementById('video-player');
      player.src = `https://www.youtube.com/embed/<?php echo htmlspecialchars($pelicula['trailer_id']); ?>?autoplay=1`;
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    
    // Reproducir video del servidor
    function playVideo(url, type) {
      const modal = document.getElementById('video-modal');
      const player = document.getElementById('video-player');
      
      if (type === 'embed') {
        player.src = url;
      } else if (type === 'direct') {
        // Para enlaces directos, podrías necesitar un reproductor diferente
        player.src = url;
      } else if (type === 'hls') {
        // Para HLS, necesitarías una librería como hls.js
        player.src = url;
      }
      
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    
    // Cerrar video
    function closeVideo() {
      const modal = document.getElementById('video-modal');
      const player = document.getElementById('video-player');
      player.src = '';
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }
    
    // Cerrar modal al hacer clic fuera del contenido (solo para el reproductor de video)
    document.getElementById('video-modal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeVideo();
      }
    });
  </script>
</body>
</html>