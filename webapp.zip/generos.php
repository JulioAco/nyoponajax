<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Obtener todos los géneros/etiquetas únicos de la base de datos
try {
    $pdo = getDBConnection();
    
    // Obtener etiquetas únicas de películas
    $stmt = $pdo->query("SELECT etiquetas FROM peliculas WHERE etiquetas IS NOT NULL AND etiquetas != ''");
    $etiquetas_peliculas = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Obtener etiquetas únicas de series
    $stmt = $pdo->query("SELECT etiquetas FROM series WHERE etiquetas IS NOT NULL AND etiquetas != ''");
    $etiquetas_series = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Combinar y procesar todas las etiquetas
    $todas_etiquetas = array_merge($etiquetas_peliculas, $etiquetas_series);
    
    $generos = [];
    
    foreach ($todas_etiquetas as $etiqueta_grupo) {
        $etiquetas = explode(',', $etiqueta_grupo);
        foreach ($etiquetas as $etiqueta) {
            $etiqueta_limpia = trim($etiqueta);
            if (!empty($etiqueta_limpia) && !in_array($etiqueta_limpia, $generos)) {
                $generos[] = $etiqueta_limpia;
            }
        }
    }
    
    // Ordenar alfabéticamente
    sort($generos);
    
    // Obtener contenido por género si se seleccionó un género
    $contenido_por_genero = [];
    $genero_actual = isset($_GET['genero']) ? trim($_GET['genero']) : '';
    
    if (!empty($genero_actual)) {
        // Buscar películas con este género
        $stmt = $pdo->prepare("
            SELECT id, titulo as nombre, portada_url, 'pelicula' as tipo, anio as año
            FROM peliculas 
            WHERE etiquetas LIKE :genero
            ORDER BY titulo
            LIMIT 20
        ");
        $stmt->execute([':genero' => '%' . $genero_actual . '%']);
        $peliculas_genero = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Buscar series con este género
        $stmt = $pdo->prepare("
            SELECT id, nombre, portada_url, 'serie' as tipo, anio_inicio as año
            FROM series 
            WHERE etiquetas LIKE :genero
            ORDER BY nombre
            LIMIT 20
        ");
        $stmt->execute([':genero' => '%' . $genero_actual . '%']);
        $series_genero = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $contenido_por_genero = array_merge($peliculas_genero, $series_genero);
        
        // Ordenar por nombre
        usort($contenido_por_genero, function($a, $b) {
            return strcmp($a['nombre'], $b['nombre']);
        });
    }
    
} catch (PDOException $e) {
    error_log("Error al obtener géneros: " . $e->getMessage());
    $generos = [];
    $contenido_por_genero = [];
}

// Cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Géneros</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />

  <style>
    :root {
      --bg: #000000;
      --bg-secondary: #151515;
      --card-bg: #1c1c1e;
      --text: #ffffff;
      --text-secondary: #ebebf599;
      --green: #30d158;
      --radius: 1.5rem;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    
    html, body {
      height: 100%;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      overflow-x: hidden;
    }
    
    /* Header estilo iOS */
    header {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      background: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 1000;
      border-bottom: 0.5px solid rgba(255, 255, 255, 0.1);
    }
    
    .back-button {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: var(--text);
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .back-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    .header-title {
      font-size: 1.1rem;
      font-weight: 600;
      letter-spacing: -0.5px;
      text-align: center;
      flex: 1;
      padding: 0 1rem;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    /* Contenido principal */
    .main-container {
      padding: 1.5rem;
      padding-bottom: 5rem;
    }
    
    /* Breadcrumb */
    .breadcrumb {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-bottom: 1.5rem;
      color: var(--text-secondary);
      font-size: 0.9rem;
    }
    
    .breadcrumb a {
      color: var(--green);
      text-decoration: none;
    }
    
    .breadcrumb span {
      color: var(--text-secondary);
    }
    
    /* Grid de géneros */
    .generos-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .genero-card {
      background: var(--card-bg);
      border-radius: var(--radius);
      padding: 1.5rem 1rem;
      text-align: center;
      text-decoration: none;
      color: var(--text);
      transition: all 0.3s ease;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .genero-card:hover {
      background: var(--green);
      color: black;
      transform: translateY(-2px);
      box-shadow: 0 10px 20px rgba(48, 209, 88, 0.3);
    }
    
    .genero-card.active {
      background: var(--green);
      color: black;
      font-weight: 600;
    }
    
    .genero-icon {
      font-size: 2rem;
      margin-bottom: 0.5rem;
      display: block;
    }
    
    .genero-name {
      font-weight: 600;
      font-size: 0.9rem;
    }
    
    /* Contenido del género */
    .genero-content {
      margin-top: 2rem;
    }
    
    .section-title {
      font-size: 1.35rem;
      font-weight: 700;
      margin-bottom: 1.25rem;
      letter-spacing: -0.25px;
    }
    
    .contenido-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 1.25rem;
    }
    
    .contenido-card {
      border-radius: var(--radius);
      overflow: hidden;
      transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
      background: var(--card-bg);
      aspect-ratio: 2/3;
    }
    
    .contenido-card:hover {
      transform: scale(1.05);
    }
    
    .contenido-poster {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    
    .no-content {
      text-align: center;
      color: var(--text-secondary);
      padding: 2rem;
      grid-column: 1 / -1;
    }
    
    .no-content-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
      opacity: 0.5;
    }
    
    /* Barra de navegación inferior estilo iOS */
    .bottom-nav {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 0.75rem 1rem;
      background: rgba(28, 28, 30, 0.9);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-top: 0.5px solid rgba(255, 255, 255, 0.1);
      z-index: 1000;
    }
    
    .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      color: var(--text-secondary);
      font-size: 0.7rem;
      gap: 0.25rem;
      padding: 0.5rem;
      border-radius: var(--radius);
      transition: all 0.2s;
    }
    
    .nav-item.active {
      color: var(--green);
    }
    
    .nav-item:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .nav-icon {
      font-size: 1.5rem;
      font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
    }
    
    .nav-item.active .nav-icon {
      font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .generos-grid {
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
      }
      
      .contenido-grid {
        grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
        gap: 1rem;
      }
    }
    
    @media (max-width: 480px) {
      .main-container {
        padding: 1rem;
        padding-bottom: 5rem;
      }
      
      .generos-grid {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 0.8rem;
      }
      
      .contenido-grid {
        grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
        gap: 0.8rem;
      }
      
      .genero-card {
        padding: 1rem 0.5rem;
      }
      
      .genero-icon {
        font-size: 1.5rem;
      }
    }
  </style>
</head>
<body>
  <header>
    <button class="back-button" onclick="history.back()">
      <span class="material-symbols-rounded">arrow_back</span>
    </button>
    <div class="header-title">
      <?php echo !empty($genero_actual) ? htmlspecialchars($genero_actual) : 'Géneros'; ?>
    </div>
    <div style="width: 40px;"></div>
  </header>
  
  <div class="main-container">
    <!-- Breadcrumb -->
    <div class="breadcrumb">
      <a href="generos.php">Géneros</a>
      <?php if (!empty($genero_actual)): ?>
        <span class="material-symbols-rounded" style="font-size: 1rem;">chevron_right</span>
        <span><?php echo htmlspecialchars($genero_actual); ?></span>
      <?php endif; ?>
    </div>
    
    <!-- Grid de géneros -->
    <div class="generos-grid">
      <?php foreach ($generos as $genero): ?>
        <a href="generos.php?genero=<?php echo urlencode($genero); ?>" class="genero-card <?php echo $genero === $genero_actual ? 'active' : ''; ?>">
          <span class="material-symbols-rounded genero-icon">theaters</span>
          <div class="genero-name"><?php echo htmlspecialchars($genero); ?></div>
        </a>
      <?php endforeach; ?>
    </div>
    
    <!-- Contenido del género seleccionado -->
    <?php if (!empty($genero_actual)): ?>
    <div class="genero-content">
      <h2 class="section-title">Contenido de <?php echo htmlspecialchars($genero_actual); ?></h2>
      
      <?php if (!empty($contenido_por_genero)): ?>
        <div class="contenido-grid">
          <?php foreach ($contenido_por_genero as $item): ?>
            <a href="<?php echo $item['tipo'] === 'pelicula' ? 'pelicula.php?id=' . $item['id'] : 'serie.php?id=' . $item['id']; ?>" class="contenido-card">
              <img src="<?php echo htmlspecialchars($item['portada_url']); ?>" alt="<?php echo htmlspecialchars($item['nombre']); ?>" class="contenido-poster"
                   onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWMxYzFlIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iI2ViZWJfNTk5IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zNWVtIj5TaW4gaW1hZ2VuPC90ZXh0Pjwvc3ZnPg=='">
            </a>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="no-content">
          <div class="no-content-icon">
            <span class="material-symbols-rounded">search_off</span>
          </div>
          <p>No hay contenido disponible para este género</p>
        </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
  
  <!-- Barra de navegación inferior -->
  <nav class="bottom-nav">
    <a href="homev2.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">home</span>
      <span>Inicio</span>
    </a>
    <a href="peliculas.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">movie</span>
      <span>Películas</span>
    </a>
    <a href="series.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">live_tv</span>
      <span>Series</span>
    </a>
    <a href="generos.php" class="nav-item active">
      <span class="material-symbols-rounded nav-icon">category</span>
      <span>Géneros</span>
    </a>
    <a href="?logout=true" class="nav-item">
      <span class="material-symbols-rounded nav-icon">account_circle</span>
      <span>Cuenta</span>
    </a>
  </nav>
  
  <script>
    // Confirmar cierre de sesión
    document.querySelector('a[href="?logout=true"]').addEventListener('click', function(e) {
      e.preventDefault();
      if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
        window.location.href = '?logout=true';
      }
    });
    
    // Scroll suave al hacer clic en un género
    document.querySelectorAll('.genero-card').forEach(card => {
      card.addEventListener('click', function(e) {
        if (this.classList.contains('active')) {
          e.preventDefault();
          window.scrollTo({
            top: document.querySelector('.genero-content').offsetTop - 80,
            behavior: 'smooth'
          });
        }
      });
    });
  </script>
</body>
</html>