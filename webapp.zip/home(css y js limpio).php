<?php
session_start();
require_once 'includes/config.php';

// Verificar si el usuario tiene una sesión válida
if (!isset($_SESSION['token']) || $_SESSION['user_ip'] !== $_SERVER['REMOTE_ADDR']) {
    header("Location: index.php");
    exit;
}

// Obtener datos de la base de datos
try {
    $pdo = getDBConnection();
    
    // Obtener películas destacadas
    $stmt = $pdo->prepare("
        SELECT * FROM peliculas 
        WHERE group_id = 1 
        ORDER BY fecha_creacion DESC 
        LIMIT 12
    ");
    $stmt->execute();
    $peliculas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener series destacadas
    $stmt = $pdo->prepare("
        SELECT * FROM series 
        WHERE group_id = 1 
        ORDER BY fecha_creacion DESC 
        LIMIT 12
    ");
    $stmt->execute();
    $series = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener episodios recientes (últimos 10 episodios agregados)
    $stmt = $pdo->prepare("
        SELECT e.*, s.nombre as serie_nombre, s.portada_url as serie_portada
        FROM episodios e
        JOIN series s ON e.serie_id = s.id
        WHERE e.group_id = 1 
        ORDER BY e.fecha_creacion DESC 
        LIMIT 10
    ");
    $stmt->execute();
    $episodios_recientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener estrenos (películas y series agregadas en los últimos 7 días)
    $stmt = $pdo->prepare("
        (SELECT id, titulo as nombre, portada_url, 'pelicula' as tipo, fecha_creacion 
         FROM peliculas 
         WHERE group_id = 1 AND fecha_creacion >= DATE_SUB(NOW(), INTERVAL 7 DAY)
         ORDER BY fecha_creacion DESC 
         LIMIT 8)
        UNION
        (SELECT id, nombre, portada_url, 'serie' as tipo, fecha_creacion 
         FROM series 
         WHERE group_id = 1 AND fecha_creacion >= DATE_SUB(NOW(), INTERVAL 7 DAY)
         ORDER BY fecha_creacion DESC 
         LIMIT 8)
        ORDER BY fecha_creacion DESC 
        LIMIT 16
    ");
    $stmt->execute();
    $estrenos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener películas por categorías
    $categorias_peliculas = ['Acción', 'Drama', 'Comedia', 'Ciencia Ficción'];
    $peliculas_por_categoria = [];
    
    foreach ($categorias_peliculas as $categoria) {
        $stmt = $pdo->prepare("
            SELECT * FROM peliculas 
            WHERE etiquetas LIKE :categoria 
            ORDER BY puntuacion DESC 
            LIMIT 10
        ");
        $stmt->execute([':categoria' => '%' . $categoria . '%']);
        $peliculas_por_categoria[$categoria] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Obtener series por categorías
    $categorias_series = ['Drama', 'Comedia', 'Acción', 'Ciencia Ficción'];
    $series_por_categoria = [];
    
    foreach ($categorias_series as $categoria) {
        $stmt = $pdo->prepare("
            SELECT * FROM series 
            WHERE etiquetas LIKE :categoria 
            ORDER BY puntuacion DESC 
            LIMIT 10
        ");
        $stmt->execute([':categoria' => '%' . $categoria . '%']);
        $series_por_categoria[$categoria] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
} catch (PDOException $e) {
    error_log("Error al obtener datos: " . $e->getMessage());
    $peliculas = $series = $episodios_recientes = $estrenos = [];
    $peliculas_por_categoria = $series_por_categoria = [];
}

// Cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Inicio</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />

  <style>
    :root {
      --bg: #000000;
      --bg-secondary: #151515;
      --card-bg: #1c1c1e;
      --text: #ffffff;
      --text-secondary: #ebebf599;
      --green: #30d158;
      --radius: 1.5rem;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    
    html, body {
      height: 100%;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      overflow-x: hidden;
    }
    
    /* Header estilo iOS */
    header {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      background: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      z-index: 1000;
      border-bottom: 0.5px solid rgba(255, 255, 255, 0.1);
    }
    
    .logo {
      display: flex;
      align-items: center;
    }
    
    .logo img {
      height: 32px;
      user-select: none;
    }
    
    .header-title {
      font-size: 1.5rem;
      font-weight: 700;
      letter-spacing: -0.5px;
    }
    
    .header-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    
    .icon-button {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: var(--text);
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .icon-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    /* Contenido principal */
    main {
      padding: 1.5rem;
      padding-bottom: 5rem;
    }
    
    /* Secciones */
    .section {
      margin-bottom: 2.5rem;
    }
    
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
    }
    
    .section-title {
      font-size: 1.35rem;
      font-weight: 700;
      letter-spacing: -0.25px;
      margin-bottom: 1.25rem;
    }
    
    .view-all {
      color: var(--green);
      text-decoration: none;
      font-size: 0.9rem;
      font-weight: 500;
    }
    
    /* Grids */
    .grid {
      display: grid;
      gap: 1.25rem;
    }
    
    .featured-grid {
      grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    }
    
    .category-grid {
      grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    }
    
    .episodes-grid {
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    }
    
    /* Cards */
    .card {
      border-radius: var(--radius);
      overflow: hidden;
      transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
      background: var(--card-bg);
    }
    
    .card:hover {
      transform: scale(1.05);
    }
    
    .movie-card, .serie-card {
      aspect-ratio: 2/3;
    }
    
    .estreno-card {
      aspect-ratio: 2/3;
    }
    
    .episode-card {
      aspect-ratio: 16/9;
      position: relative;
    }
    
    .card-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    
    .episode-overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
      padding: 1rem;
      color: white;
    }
    
    .episode-title {
      font-weight: 600;
      margin-bottom: 0.25rem;
      font-size: 0.95rem;
    }
    
    .episode-info {
      font-size: 0.8rem;
      color: var(--text-secondary);
      display: flex;
      gap: 0.5rem;
    }
    
    .badge {
      background: var(--green);
      color: black;
      padding: 0.2rem 0.5rem;
      border-radius: 0.5rem;
      font-size: 0.7rem;
      font-weight: 600;
    }
    
    /* Barra de navegación inferior estilo iOS */
    .bottom-nav {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 0.75rem 1rem;
      background: rgba(28, 28, 30, 0.9);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-top: 0.5px solid rgba(255, 255, 255, 0.1);
      z-index: 1000;
    }
    
    .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      color: var(--text-secondary);
      font-size: 0.7rem;
      gap: 0.25rem;
      padding: 0.5rem;
      border-radius: var(--radius);
      transition: all 0.2s;
    }
    
    .nav-item.active {
      color: var(--green);
    }
    
    .nav-item:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .nav-icon {
      font-size: 1.5rem;
      font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
    }
    
    .nav-item.active .nav-icon {
      font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24;
    }
    
    /* Modal para trailers */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.9);
      z-index: 2000;
      justify-content: center;
      align-items: center;
      opacity: 0;
      transition: opacity 0.3s;
    }
    
    .modal.show {
      display: flex;
      opacity: 1;
    }
    
    .modal-content {
      position: relative;
      width: 90%;
      max-width: 900px;
    }
    
    .close-modal {
      position: absolute;
      top: -45px;
      right: 0;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 1.25rem;
      transition: background 0.2s;
    }
    
    .close-modal:hover {
      background: rgba(255, 255, 255, 0.3);
    }
    
    .trailer-container {
      position: relative;
      padding-bottom: 56.25%;
      height: 0;
      border-radius: var(--radius);
      overflow: hidden;
    }
    
    .trailer-iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      border: none;
    }
    
    /* Responsive */
    @media (max-width: 1024px) {
      .episodes-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      }
    }
    
    @media (max-width: 768px) {
      .featured-grid {
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
        gap: 1rem;
      }
      
      .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
        gap: 1rem;
      }
      
      .episodes-grid {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      }
      
      .header-title {
        font-size: 1.25rem;
      }
    }
    
    @media (max-width: 480px) {
      main {
        padding: 1rem;
        padding-bottom: 5rem;
      }
      
      .featured-grid {
        grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
        gap: 0.8rem;
      }
      
      .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 0.8rem;
      }
      
      .episodes-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
      }
    }
    
    
    
    
    
    
    
    /* Animación shimmer para carga */
@keyframes loadingShimmer {
  0% {
    background-position: -200px 0;
  }
  100% {
    background-position: calc(200px + 100%) 0;
  }
}

/* Card en modo carga */
.card.loading {
  position: relative;
  background: #2a2a2a;
  overflow: hidden;
}

.card.loading::before {
  content: "";
  display: block;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    90deg,
    #2a2a2a 0px,
    #3a3a3a 40px,
    #2a2a2a 80px
  );
  background-size: 200px 100%;
  animation: loadingShimmer 1.2s infinite;
}




  </style>
  
<style>
  /* Loader en pantalla completa */
  #loader-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #0a0a0a;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .loader {
    width: 100px;
    height: 100px;
    background: linear-gradient(
      165deg,
      rgba(255, 255, 255, 1) 0%,
      rgb(220, 220, 220) 40%,
      rgb(170, 170, 170) 98%,
      rgb(10, 10, 10) 100%
    );
    border-radius: 50%;
    position: relative;
    box-shadow: 0 0 40px rgba(255,255,255,0.3);
  }

  .loader:before {
    position: absolute;
    content: "";
    width: 100%;
    height: 100%;
    border-radius: 100%;
    border-bottom: 0 solid #ffffff05;
    box-shadow: 0 -10px 20px 20px #ffffff40 inset,
      0 -5px 15px 10px #ffffff50 inset, 
      0 -2px 5px #ffffff80 inset,
      0 -3px 2px #ffffffbb inset, 
      0 2px 0px #ffffff, 
      0 2px 3px #ffffff,
      0 5px 5px #ffffff90, 
      0 10px 15px #ffffff60, 
      0 10px 20px 20px #ffffff40;
    filter: blur(3px);
    animation: rotate 2s linear infinite;
  }

  @keyframes rotate {
    100% { transform: rotate(360deg) }
  }

  /* Animación de salida suave */
  .fade-out {
    opacity: 0;
    transition: opacity 0.6s ease-out;
  }
</style>
</head>
<body>
  <header>
    <div class="logo">
      <span class="header-title">Titan</span>
    </div>
    
    <div class="header-actions">
      <button class="icon-button" onclick="openSearch()">
        <span class="material-symbols-rounded">search</span>
      </button>
      <button class="icon-button" onclick="location.href='?logout=true'">
        <span class="material-symbols-rounded">logout</span>
      </button>
    </div>
  </header>
  
  <main>
    <!-- Sección de Estrenos -->
    <?php if (!empty($estrenos)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Estrenos Recientes</h2>
        <a href="#" class="view-all">Ver todos</a>
      </div>
      <div class="grid featured-grid">
        <?php foreach ($estrenos as $estreno): ?>
        <a href="<?php echo $estreno['tipo'] === 'pelicula' ? 'pelicula.php?id=' : 'serie.php?id='; ?><?php echo $estreno['id']; ?>" class="card estreno-card loading">
          <img src="<?php echo htmlspecialchars($estreno['portada_url']); ?>" alt="<?php echo htmlspecialchars($estreno['nombre']); ?>" class="card-image">
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Sección de Episodios Recientes -->
    <?php if (!empty($episodios_recientes)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Episodios Recientes</h2>
        <a href="#" class="view-all">Ver todos</a>
      </div>
      <div class="grid episodes-grid">
        <?php foreach ($episodios_recientes as $episodio): ?>
        <a href="serie.php?id=<?php echo $episodio['serie_id']; ?>" class="card episode-card loading">
          <img src="<?php echo !empty($episodio['imagen_episodio']) ? htmlspecialchars($episodio['imagen_episodio']) : htmlspecialchars($episodio['serie_portada']); ?>" alt="<?php echo htmlspecialchars($episodio['serie_nombre']); ?>" class="card-image">
          <div class="episode-overlay">
            <div class="episode-title"><?php echo htmlspecialchars($episodio['serie_nombre']); ?></div>
            <div class="episode-info">
              <span>T<?php echo $episodio['temporada']; ?> E<?php echo $episodio['episodio']; ?></span>
              <span>•</span>
              <span><?php echo htmlspecialchars($episodio['titulo']); ?></span>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Sección de Películas Destacadas -->
    <?php if (!empty($peliculas)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Películas Destacadas</h2>
        <a href="peliculas.php" class="view-all">Ver todas</a>
      </div>
      <div class="grid featured-grid">
        <?php foreach ($peliculas as $pelicula): ?>
        <a href="pelicula.php?id=<?php echo $pelicula['id']; ?>" class="card movie-card loading">
          <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" class="card-image">
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Sección de Series Destacadas -->
    <?php if (!empty($series)): ?>
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">Series Destacadas</h2>
        <a href="series.php" class="view-all">Ver todas</a>
      </div>
      <div class="grid featured-grid">
        <?php foreach ($series as $serie): ?>
        <a href="serie.php?id=<?php echo $serie['id']; ?>" class="card serie-card loading">
          <img src="<?php echo htmlspecialchars($serie['portada_url']); ?>" alt="<?php echo htmlspecialchars($serie['nombre']); ?>" class="card-image">
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- Secciones de Películas por Categoría -->
    <?php foreach ($peliculas_por_categoria as $categoria => $peliculas_categoria): ?>
      <?php if (!empty($peliculas_categoria)): ?>
      <section class="section">
        <h2 class="section-title">Películas de <?php echo htmlspecialchars($categoria); ?></h2>
        <div class="grid category-grid">
          <?php foreach ($peliculas_categoria as $pelicula): ?>
          <a href="pelicula.php?id=<?php echo $pelicula['id']; ?>" class="card movie-card loading">
            <img src="<?php echo htmlspecialchars($pelicula['portada_url']); ?>" alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" class="card-image">
          </a>
          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>
    <?php endforeach; ?>

    <!-- Secciones de Series por Categoría -->
    <?php foreach ($series_por_categoria as $categoria => $series_categoria): ?>
      <?php if (!empty($series_categoria)): ?>
      <section class="section">
        <h2 class="section-title">Series de <?php echo htmlspecialchars($categoria); ?></h2>
        <div class="grid category-grid">
          <?php foreach ($series_categoria as $serie): ?>
          <a href="serie.php?id=<?php echo $serie['id']; ?>" class="card serie-card loading">
            <img src="<?php echo htmlspecialchars($serie['portada_url']); ?>" alt="<?php echo htmlspecialchars($serie['nombre']); ?>" class="card-image">
          </a>
          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>
    <?php endforeach; ?>
  </main>
  
  <!-- Barra de navegación inferior -->
  <nav class="bottom-nav">
    <a href="home.php" class="nav-item active">
      <span class="material-symbols-rounded nav-icon">home</span>
      <span>Inicio</span>
    </a>
    <a href="peliculas.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">movie</span>
      <span>Películas</span>
    </a>
    <a href="series.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">live_tv</span>
      <span>Series</span>
    </a>
    <a href="buscar.php" class="nav-item">
      <span class="material-symbols-rounded nav-icon">search</span>
      <span>Buscar</span>
    </a>
    <a href="?logout=true" class="nav-item">
      <span class="material-symbols-rounded nav-icon">account_circle</span>
      <span>Cuenta</span>
    </a>
  </nav>
  
  <!-- Modal para trailers -->
  <div id="trailer-modal" class="modal">
    <div class="modal-content">
      <button class="close-modal" onclick="closeModal()">×</button>
      <div class="trailer-container">
        <iframe id="trailer-iframe" class="trailer-iframe" src="" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
  
  <script>
    function playTrailer(trailerId) {
      const modal = document.getElementById('trailer-modal');
      const iframe = document.getElementById('trailer-iframe');
      iframe.src = `https://www.youtube.com/embed/${trailerId}?autoplay=1`;
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    
    function closeModal() {
      const modal = document.getElementById('trailer-modal');
      const iframe = document.getElementById('trailer-iframe');
      iframe.src = '';
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }
    
    // Cerrar modal al hacer clic fuera del contenido
    document.getElementById('trailer-modal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeModal();
      }
    });
    
    function openSearch() {
      alert('Funcionalidad de búsqueda próximamente');
    }
    
    // Confirmar cierre de sesión
    document.querySelector('a[href="?logout=true"]').addEventListener('click', function(e) {
      e.preventDefault();
      if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
        window.location.href = '?logout=true';
      }
    });
  </script>
  <script>
// Quitar animación de carga cuando la imagen termine de cargar
document.querySelectorAll('.card img').forEach(img => {
  const card = img.closest('.card');

  // Si ya está cargada (cache del navegador)
  if (img.complete) {
    card.classList.remove('loading');
  } else {
    img.addEventListener('load', () => {
      card.classList.remove('loading');
    });

    img.addEventListener('error', () => {
      card.classList.remove('loading');
    });
  }
});

  </script>
  <script>
// Loader avanzado con JS
document.addEventListener("DOMContentLoaded", function () {
  // Crear overlay
  const overlay = document.createElement("div");
  overlay.id = "loader-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "0";
  overlay.style.left = "0";
  overlay.style.width = "100%";
  overlay.style.height = "100%";
  overlay.style.background = "#000"; // fondo oscuro
  overlay.style.display = "flex";
  overlay.style.alignItems = "center";
  overlay.style.justifyContent = "center";
  overlay.style.zIndex = "9999";

  // Insertar loader
  overlay.innerHTML = `<span class="loader"></span>`;
  document.body.appendChild(overlay);

  // Al cargar todo el contenido -> quitar loader
  window.addEventListener("load", () => {
    setTimeout(() => {
      overlay.style.opacity = "0";
      overlay.style.transition = "opacity 0.6s ease";
      setTimeout(() => overlay.remove(), 600);
    }, 4000); // pequeño delay para elegancia
  });
});
</script>

</body>
</html>