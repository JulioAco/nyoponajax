<?php
ob_start();
require_once 'includes/config.php';

// Iniciar archivo de log para depuración
ini_set('log_errors', 1);
ini_set('error_log', 'logs/php_errors.log');

// Función para obtener IP pública real
function getPublicIp() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.ipify.org');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $ip = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($ip && $httpCode === 200) {
        return $ip;
    }
    
    // Fallback: intentar con otro servicio
    $ip = @file_get_contents('https://checkip.amazonaws.com');
    if ($ip !== false) {
        return trim($ip);
    }
    
    return 'Unknown';
}

// Función para obtener IP local del cliente
function getClientIp() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        return $_SERVER['REMOTE_ADDR'];
    }
    return 'Unknown';
}

// Función para generar un token único
function generateUniqueToken($pdo, $length = 32) {
    try {
        do {
            $token = bin2hex(random_bytes($length));
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM invitaciones WHERE token = ?");
            $stmt->execute([$token]);
            $count = $stmt->fetchColumn();
        } while ($count > 0);
        return $token;
    } catch (Exception $e) {
        error_log("Error en generateUniqueToken: " . $e->getMessage());
        return false;
    }
}

// Verificar si ya existe un token válido en la cookie
if (isset($_COOKIE['auth_token'])) {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT * FROM invitaciones WHERE token = ? AND activo = 1");
        $stmt->execute([$_COOKIE['auth_token']]);
        $invitacion = $stmt->fetch();
        
        if ($invitacion) {
            error_log("Token válido encontrado en cookie: " . $_COOKIE['auth_token']);
            header("Location: home.php");
            ob_end_flush();
            exit;
        } else {
            error_log("Token inválido en cookie: " . $_COOKIE['auth_token']);
            setcookie('auth_token', '', time() - 3600, '/');
        }
    } catch (PDOException $e) {
        error_log("Error al verificar cookie en index.php: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo = trim($_POST['codigo'] ?? '');
    
    if (empty($codigo)) {
        $error = "Debes ingresar un código";
        error_log("Error: Código vacío enviado en POST");
    } else {
        try {
            $pdo = getDBConnection();
            $pdo->beginTransaction();
            
            // Verificar si el código existe y está activo
            $stmt = $pdo->prepare("SELECT * FROM invitaciones WHERE codigo = ? AND activo = 1");
            $stmt->execute([$codigo]);
            $invitacion = $stmt->fetch();

            if ($invitacion) {
                error_log("Código encontrado: $codigo, token: " . ($invitacion['token'] ?? 'NULL'));
                
                // Obtener información del dispositivo
                $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
                $publicIp = getPublicIp();
                $localIp = getClientIp();
                
                if ($invitacion['token'] === null) {
                    // Código no usado, asignar nuevo token y guardar información del dispositivo
                    $generated_token = generateUniqueToken($pdo);
                    if ($generated_token === false) {
                        throw new Exception("No se pudo generar un token único");
                    }
                    
                    // Actualizar con token e información del dispositivo
                    $stmt = $pdo->prepare("UPDATE invitaciones SET token = ?, user_agent = ?, ip_publica = ?, ip_local = ?, fecha_uso = NOW() WHERE codigo = ?");
                    $stmt->execute([$generated_token, $userAgent, $publicIp, $localIp, $codigo]);
                    
                    // Registrar información obtenida
                    error_log("Información del dispositivo guardada - User Agent: $userAgent, IP Pública: $publicIp, IP Local: $localIp");
                    
                    // Establecer cookie persistente
                    $cookie_set = setcookie('auth_token', $generated_token, 0, '/', '', true, true);
                    if (!$cookie_set) {
                        error_log("Error: No se pudo establecer la cookie auth_token");
                    } else {
                        error_log("Cookie auth_token establecida: $generated_token");
                    }
                    
                    $pdo->commit();
                    error_log("Redirigiendo a home.php tras asignar token");
                    header("Location: home.php");
                    ob_end_flush();
                    exit;
                } elseif ($invitacion['token'] === ($_COOKIE['auth_token'] ?? '')) {
                    // El token en la cookie coincide, permitir acceso
                    error_log("Token coincide, redirigiendo a home.php");
                    header("Location: home.php");
                    ob_end_flush();
                    exit;
                } else {
                    // Código ya usado por otro dispositivo
                    $error = "Este código ya está en uso en otro dispositivo";
                    error_log("Error: Código $codigo ya usado por otro dispositivo");
                    
                    // Registrar información del intento fallido
                    error_log("Intento de acceso fallido - User Agent: $userAgent, IP Pública: $publicIp, IP Local: $localIp");
                }
            } else {
                $error = "Código inválido o inactivo";
                error_log("Error: Código $codigo no encontrado o inactivo");
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Error al procesar: " . htmlspecialchars($e->getMessage());
            error_log("Error PDO en POST: " . $e->getMessage());
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Error al procesar: " . htmlspecialchars($e->getMessage());
            error_log("Error general en POST: " . $e->getMessage());
        }
    }
}
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • Acceso por código</title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@300" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/materialize.css" />
  <style>
    :root{
      --bg:#0b0b0b;
      --text:#e9e9e9;
      --muted:#a0a0a0;
      --green:#29d14d;
      --radius:14px;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      background:var(--bg);
      color:var(--text);
      font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;
      display:grid;
      place-items:center;
    }
    .wrap{
      width:min(520px,92vw);
      padding:32px 24px 24px;
    }
    .logo{
      display:grid;
      place-items:center;
      margin:10vh 0 40px;
    }
    .logo img{
      width:min(300px,30vw);
      max-width:360px;
      user-select:none;
    }
    label{
      display:block;
      font-size:.95rem;
      margin:0 0 8px;
      color:var(--muted);
    }
    .field{
      position:relative;
      display:flex;
      align-items:center;
    }
    input{
      width:100%;
      height:58px;
      background:transparent;
      color:var(--text);
      border:2px solid var(--green);
      border-radius:var(--radius);
      outline:none;
      padding:0 56px 0 18px;
      font-size:1.05rem;
      letter-spacing:.6px;
      transition:border-color .2s;
    }
    input:focus{
      border-color:var(--green);
    }
    .eye{
      position:absolute;
      right:8px;
      height:42px;
      width:42px;
      border:0;
      background:transparent;
      color:var(--text);
      border-radius:12px;
      cursor:pointer;
      display:grid;
      place-items:center;
    }
    .eye:hover{background:#ffffff12}
    .btn{
      margin-top:26px;
      width:100%;
      height:58px;
      border:2px solid var(--green);
      background:transparent;
      color:var(--green);
      border-radius:var(--radius);
      font-weight:600;
      letter-spacing:.28em;
      text-transform:uppercase;
      cursor:pointer;
      transition:transform .06s ease, background .2s;
    }
    .btn:active{transform:translateY(1px)}
    .btn:hover{background:#0f0f0f}
    .helper{
      margin-top:18px;
      text-align:center;
      color:var(--muted);
      font-size:.95rem;
    }
    .helper a{
      color:var(--text);
      text-decoration:none;
      font-weight:600;
      border-bottom:1px solid transparent;
      transition:color .2s, border-color .2s;
    }
    .helper a:hover{
      color:var(--green);
      border-color:var(--green);
    }
    .error{
      color:#ff4d4d;
      text-align:center;
      margin-top:18px;
      font-size:.95rem;
    }
  </style>
</head>
<body>
  <main class="wrap">
    <div class="logo">
      <img src="https://cdn.stickers.gg/stickers/4196-doog-street.png" alt="Logo" />
    </div>

    <form id="form" method="POST" autocomplete="off" novalidate>
      <label for="codigo">Código de invitación</label>
      <div class="field">
        <input id="codigo" name="codigo" type="password" placeholder="Ingresa tu código" required />
        <button class="eye" type="button" aria-label="Mostrar u ocultar código">
          <span class="material-symbols-rounded">visibility</span>
        </button>
      </div>

      <button class="btn" type="submit">ACCEDER</button>

      <p class="helper">
        ¿No tienes código de invitación?
        <a href="go:code" id="obtener">OBTENER CÓDIGO AQUÍ</a>
      </p>

      <?php if (isset($error)): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>
    </form>
  </main>

  <script>
    const input = document.getElementById('codigo');
    const eyeBtn = document.querySelector('.eye');
    const eyeIcon = eyeBtn.querySelector('.material-symbols-rounded');
    const form = document.getElementById('form');

    document.addEventListener('DOMContentLoaded', () => {
        input.focus();
    });

    eyeBtn.addEventListener('click', () => {
        const isPwd = input.type === 'password';
        input.type = isPwd ? 'text' : 'password';
        eyeIcon.textContent = isPwd ? 'visibility_off' : 'visibility';
    });

    form.addEventListener('submit', (e) => {
        if (!input.value.trim()) {
            e.preventDefault();
            input.classList.add('error');
            setTimeout(() => input.classList.remove('error'), 1000);
        }
    });
  </script>
</body>
</html>