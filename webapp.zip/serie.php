<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';


// Obtener ID de la serie desde la URL
$serie_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($serie_id <= 0) {
    header("Location: home.php");
    exit;
}

// Obtener información de la serie
try {
    $pdo = getDBConnection();
    
    // Obtener datos de la serie
    $stmt = $pdo->prepare("SELECT * FROM series WHERE id = ?");
    $stmt->execute([$serie_id]);
    $serie = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$serie) {
        header("Location: home.php");
        exit;
    }
    
    // Obtener temporadas y episodios
    $stmt = $pdo->prepare("
        SELECT temporada, COUNT(*) as episodios_count 
        FROM episodios 
        WHERE serie_id = ? 
        GROUP BY temporada 
        ORDER BY temporada
    ");
    $stmt->execute([$serie_id]);
    $temporadas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener episodios de la primera temporada por defecto
    $temporada_actual = 1;
    if (isset($_GET['temporada']) && is_numeric($_GET['temporada'])) {
        $temporada_actual = (int)$_GET['temporada'];
    } elseif (!empty($temporadas)) {
        $temporada_actual = (int)$temporadas[0]['temporada'];
    }
    
    $stmt = $pdo->prepare("
        SELECT * FROM episodios 
        WHERE serie_id = ? AND temporada = ? 
        ORDER BY episodio
    ");
    $stmt->execute([$serie_id, $temporada_actual]);
    $episodios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Agrupar servidores por episodio
    $episodios_agrupados = [];
    foreach ($episodios as $episodio) {
        $ep_key = $episodio['temporada'] . 'x' . sprintf('%02d', $episodio['episodio']);
        if (!isset($episodios_agrupados[$ep_key])) {
            $episodios_agrupados[$ep_key] = [
                'titulo' => $episodio['titulo'],
                'imagen' => $episodio['imagen_episodio'],
                'servidores' => []
            ];
        }
        $episodios_agrupados[$ep_key]['servidores'][$episodio['servidor']][$episodio['idioma']][] = $episodio;
    }
    
} catch (PDOException $e) {
    error_log("Error al obtener datos de la serie: " . $e->getMessage());
    header("Location: home.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Titan Hydra • <?php echo htmlspecialchars($serie['nombre']); ?></title>

  <!-- Fuente e íconos de Google -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/serie.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/JulioAco/nyoponajax/style/materialize.css">

  <style>
  .hero-backdrop {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: linear-gradient(to top, var(--bg) 0%, transparent 50%), 
                        linear-gradient(to bottom, var(--bg) 0%, transparent 20%),
                        url('<?php echo htmlspecialchars($serie['backdrop_url']); ?>');
      background-size: cover;
      background-position: center;
      filter: brightness(0.7);
    }



:root {
  --bg: #000000;
  --bg-secondary: #151515;
  --card-bg: #1c1c1e;
  --text: #ffffff;
  --text-secondary: #ebebf599;
  --green: #30d158;
  --radius: 1.5rem;
}

.servers-container {
  margin-top: 1rem;
  display: flex;
  flex-wrap: nowrap; /* Single row, no wrapping */
  gap: 0.8rem;
  padding: 0 1rem; /* Consistent padding on both sides */
  overflow-x: auto; /* Enable horizontal scrolling */
  overflow-y: hidden; /* Prevent vertical scrolling */
  width: 100%; /* Full width of parent */
  box-sizing: border-box; /* Ensure padding doesn't affect width */
  scrollbar-width: thin; /* Firefox: slim scrollbar */
  scrollbar-color: var(--text-secondary) var(--card-bg); /* Firefox: scrollbar colors */
}

.servers-container::-webkit-scrollbar {
  height: 8px; /* Webkit: scrollbar height for horizontal scroll */
}

.servers-container::-webkit-scrollbar-track {
  background: var(--card-bg); /* Webkit: scrollbar track */
}

.servers-container::-webkit-scrollbar-thumb {
  background: var(--text-secondary); /* Webkit: scrollbar thumb */
  border-radius: var(--radius);
}

.server-group {
  margin-bottom: 0; /* Remove bottom margin */
  flex: 0 0 auto; /* Prevent stretching */
}

.server-name {
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.server-links {
  display: flex;
  flex-wrap: nowrap; /* Single row for links */
  gap: 0.8rem;
}

.server-link {
  background: rgba(255, 255, 255, 0.1);
  border: none;
  color: var(--text);
  padding: 0.8rem;
  border-radius: var(--radius);
  text-align: center;
  cursor: pointer;
  transition: transform 0.2s, background 0.2s;
  font-size: 0.9rem;
  width: 100px; /* Fixed width for square appearance */
  height: 100px; /* Fixed height for square appearance */
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-shrink: 0; /* Prevent shrinking */
}

.server-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
}

.server-link:active {
  transform: translateY(0);
}
    
    
    
    
    
    .toggle-container {
      margin: 1rem 0;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .toggle-label {
      font-size: 1rem;
      color: #fff;
    }
    .toggle-switch {
      position: relative;
      display: inline-block;
      width: 50px;
      height: 24px;
    }
    .toggle-switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: .4s;
      border-radius: 24px;
    }
    .slider:before {
      position: absolute;
      content: "";
      height: 20px;
      width: 20px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    input:checked + .slider {
      background-color: #2196F3;
    }
    input:checked + .slider:before {
      transform: translateX(26px);
    }
    .server-group.hidden {
      display: none;
    }
  </style>
</head>
<body>
  <header>
<button class="back-button" id="customBackButton">
  <span class="material-symbols-rounded">arrow_back</span>
</button>

<script>
// Configurar navegación inteligente
class NavigationManager {
  constructor() {
    this.routes = {
      'serie.php': 'series.php',
      'pelicula.php': 'peliculas.php',
      'series.php': 'home.php',
      'peliculas.php': 'home.php',
      'home.php': 'index.php'
    };
    
    this.init();
  }
  
  init() {
    // Guardar la página actual como referencia para la siguiente
    this.saveNavigationState();
  }
  
  saveNavigationState() {
    const currentPage = window.location.pathname.split('/').pop();
    sessionStorage.setItem('lastPage', currentPage);
  }
  
  getBackDestination() {
    const currentPage = window.location.pathname.split('/').pop();
    const lastPage = sessionStorage.getItem('lastPage');
    
    // Si tenemos una ruta definida, usarla
    if (this.routes[currentPage]) {
      return this.routes[currentPage];
    }
    
    // Si no, usar la última página visitada
    return lastPage || 'home.php';
  }
  
  navigateBack() {
    const destination = this.getBackDestination();
    window.location.href = destination;
  }
}

// Inicializar cuando se carga la página
const navManager = new NavigationManager();

document.getElementById('customBackButton').addEventListener('click', function() {
  navManager.navigateBack();
});

// También puedes sobreescribir el comportamiento del botón físico de atrás
window.addEventListener('popstate', function(event) {
  // Puedes agregar lógica adicional aquí si quieres
  // navManager.navigateBack();
  // event.preventDefault();
});
</script>
    <div class="header-title"><?php echo htmlspecialchars($serie['nombre']); ?></div>
    <div style="width: 40px;"></div> <!-- Espacio para equilibrar -->
  </header>
  
  <div class="hero-section">
    <div class="hero-backdrop"></div>
    <div class="hero-content">
      <img src="<?php echo htmlspecialchars($serie['portada_url']); ?>" alt="<?php echo htmlspecialchars($serie['nombre']); ?>" class="serie-poster">
      <h1 class="serie-title"><?php echo htmlspecialchars($serie['nombre']); ?></h1>
      <div class="serie-info">
        <span><?php echo htmlspecialchars($serie['anio_inicio']); 
              if ($serie['anio_fin'] && $serie['anio_fin'] != $serie['anio_inicio']) {
                  echo ' - ' . htmlspecialchars($serie['anio_fin']);
              } ?></span>
        <span>•</span>
        <span><?php echo htmlspecialchars($serie['temporadas']); ?> Temporadas</span>
        <span>•</span>
        <span><?php echo htmlspecialchars($serie['episodios']); ?> Episodios</span>
        <span>•</span>
        <span><?php echo htmlspecialchars($serie['etiquetas']); ?></span>
      </div>
      <div class="action-buttons">
        <button class="play-button" onclick="playTrailer()">
          <span class="material-symbols-rounded">play_arrow</span>
          Ver Trailer
        </button>
      </div>
    </div>
  </div>
  
  <div class="content-section">
    <div class="synopsis">
      <h2 class="section-title">Sinopsis</h2>
      <p><?php echo htmlspecialchars($serie['sinopsis']); ?></p>
    </div>
    
    <?php if (!empty($temporadas)): ?>
    <div class="temporadas-selector">
      <h2 class="section-title">Temporadas</h2>
      <div class="temporadas-grid">
        <?php foreach ($temporadas as $temporada): ?>
        <button class="temporada-button <?php echo $temporada['temporada'] == $temporada_actual ? 'active' : ''; ?>" 
                onclick="cambiarTemporada(<?php echo $temporada['temporada']; ?>)">
          Temporada <?php echo $temporada['temporada']; ?>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
    
    <div class="episodios-container">
      <h2 class="section-title">Episodios</h2>
      
      <div class="toggle-container">
        <label class="toggle-label">Reproductor externo</label>
        <label class="toggle-switch">
          <input type="checkbox" id="externalPlayerToggle">
          <span class="slider"></span>
        </label>
      </div>
      
      <?php if (!empty($episodios_agrupados)): ?>
      <div class="episodios-list">
        <?php foreach ($episodios_agrupados as $ep_key => $episodio): ?>
        <div class="episodio-card">
          <div class="episodio-header" onclick="toggleEpisodio('ep-<?php echo $ep_key; ?>')">
            <div class="episodio-number"><?php echo $ep_key; ?></div>
            <div class="episodio-info">
              <div class="episodio-title"><?php echo htmlspecialchars($episodio['titulo']); ?></div>
            </div>
            <button class="episodio-toggle">
              <span class="material-symbols-rounded">expand_more</span>
            </button>
          </div>
          
          <div class="episodio-content" id="ep-<?php echo $ep_key; ?>">
            <?php if (!empty($episodio['imagen'])): ?>
            <img src="<?php echo htmlspecialchars($episodio['imagen']); ?>" alt="<?php echo htmlspecialchars($episodio['titulo']); ?>" class="episodio-image">
            <?php endif; ?>
            
            <div class="servers-container">
              <?php foreach ($episodio['servidores'] as $servidor_nombre => $idiomas): ?>
              <div class="server-group" data-server-type="<?php 
                $server_types = array_unique(array_column($idiomas[array_key_first($idiomas)], 'link_type'));
                echo htmlspecialchars(implode(',', $server_types));
              ?>">
                <h4 class="server-name">
                  <span class="material-symbols-rounded">dns</span>
                  <?php echo htmlspecialchars($servidor_nombre); ?>
                </h4>
                
                <?php foreach ($idiomas as $idioma => $links): ?>
                <div class="server-links">
                  <?php foreach ($links as $link): ?>
                  <button class="server-link" data-link-type="<?php echo htmlspecialchars($link['link_type']); ?>" onclick="playVideo('<?php echo htmlspecialchars($link['url_video']); ?>', '<?php echo htmlspecialchars($link['link_type']); ?>', '<?php echo htmlspecialchars($ep_key . ' - ' . $episodio['titulo']); ?>')">
                    <span class="material-symbols-rounded" style="font-size: 1.2rem; margin-bottom: 0.2rem;">play_circle</span>
                    <br>
                    <?php echo htmlspecialchars($idioma); ?>
                  </button>
                  <?php endforeach; ?>
                </div>
                <?php endforeach; ?>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php else: ?>
      <p>No hay episodios disponibles para esta temporada.</p>
      <?php endif; ?>
    </div>
  </div>
  
  <!-- Modal para video -->
  <div id="video-modal" class="video-modal">
    <div class="video-header">
      <div class="video-title" id="video-modal-title">Reproduciendo episodio</div>
      <button class="close-video" onclick="closeVideo()">
        <span class="material-symbols-rounded">close</span>
      </button>
    </div>
    <div class="video-container">
      <iframe id="video-player" class="video-player" src="" allowfullscreen></iframe>
    </div>
  </div>
  
  <script>
    // Initialize toggle state from localStorage
    document.addEventListener('DOMContentLoaded', function() {
      const externalPlayerToggle = document.getElementById('externalPlayerToggle');
      const savedState = localStorage.getItem('externalPlayerEnabled');
      externalPlayerToggle.checked = savedState === 'true';
      updateServerVisibility();
      
      // Save toggle state to localStorage
      externalPlayerToggle.addEventListener('change', function() {
        localStorage.setItem('externalPlayerEnabled', this.checked);
        updateServerVisibility();
      });
    });
    
    // Update visibility of server groups based on toggle state
    function updateServerVisibility() {
      const externalPlayerToggle = document.getElementById('externalPlayerToggle');
      const isExternalPlayer = externalPlayerToggle.checked;
      const serverGroups = document.querySelectorAll('.server-group');
      
      serverGroups.forEach(group => {
        const serverTypes = group.getAttribute('data-server-type').split(',');
        const hasSupportedType = serverTypes.includes('direct') || serverTypes.includes('hls');
        
        if (isExternalPlayer) {
          group.classList.toggle('hidden', !hasSupportedType);
        } else {
          group.classList.remove('hidden');
        }
      });
    }
    
    // Cambiar temporada
    function cambiarTemporada(temporada) {
      window.location.href = `serie.php?id=<?php echo $serie_id; ?>&temporada=${temporada}`;
    }
    
    // Alternar visibilidad de episodio
    function toggleEpisodio(epId) {
      const content = document.getElementById(epId);
      const toggle = content.previousElementSibling.querySelector('.episodio-toggle');
      
      content.classList.toggle('show');
      toggle.classList.toggle('rotated');
      updateServerVisibility();
    }
    
    // Reproducir trailer
    function playTrailer() {
      const modal = document.getElementById('video-modal');
      const player = document.getElementById('video-player');
      const title = document.getElementById('video-modal-title');
      
      title.textContent = 'Trailer: <?php echo htmlspecialchars($serie['nombre']); ?>';
      player.src = `https://www.youtube.com/embed/<?php echo htmlspecialchars($serie['trailer_id']); ?>?autoplay=1`;
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    
    // Reproducir video del servidor
    function playVideo(url, type, episodeTitle) {
      const externalPlayerToggle = document.getElementById('externalPlayerToggle');
      const isExternalPlayer = externalPlayerToggle.checked;
      
      if (isExternalPlayer && (type === 'direct' || type === 'hls')) {
        const cleanedURL = url.replace(/^https?:\/\//, '');
        const intentURL = `intent://${cleanedURL}#Intent;scheme=https;package=live.mehiz.mpvkt;action=android.intent.action.VIEW;type=video/*;end`;
        window.location.href = intentURL;
      } else {
        const modal = document.getElementById('video-modal');
        const player = document.getElementById('video-player');
        const title = document.getElementById('video-modal-title');
        
        title.textContent = episodeTitle;
        
        if (type === 'embed' || type === 'direct' || type === 'hls') {
          player.src = url;
        }
        
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
      }
    }
    
    // Cerrar video
    function closeVideo() {
      const modal = document.getElementById('video-modal');
      const player = document.getElementById('video-player');
      player.src = '';
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }
    
    // Cerrar modal al hacer clic fuera del contenido
    document.getElementById('video-modal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeVideo();
      }
    });
  </script>
</body>
</html>