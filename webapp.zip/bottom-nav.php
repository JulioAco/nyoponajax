<?php
session_start();
require_once 'includes/config.php';

?>
<nav class="bottom-nav">
    <a href="home.php" class="nav-item" data-page="home">
        <span class="material-symbols-rounded nav-icon">home</span>
        <span>Inicio</span>
    </a>
    <a href="peliculas.php" class="nav-item" data-page="peliculas">
        <span class="material-symbols-rounded nav-icon">movie</span>
        <span>Películas</span>
    </a>
    <a href="series.php" class="nav-item" data-page="series">
        <span class="material-symbols-rounded nav-icon">live_tv</span>
        <span>Series</span>
    </a>
    <a href="buscar.php" class="nav-item" data-page="buscar">
        <span class="material-symbols-rounded nav-icon">search</span>
        <span>Buscar</span>
    </a>
    <a href="#" class="nav-item" id="logout-btn" data-page="cuenta">
        <span class="material-symbols-rounded nav-icon">account_circle</span>
        <span>Cuenta</span>
    </a>
</nav>